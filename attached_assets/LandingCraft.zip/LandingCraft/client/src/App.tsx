import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";

import NotFound from "@/pages/not-found";
import HomePage from "@/pages/HomePage";
import PricingPage from "@/pages/PricingPage";
import ProductPage from "@/pages/ProductPage";
import SolutionPage from "@/pages/SolutionPage";
import ResourcesPage from "@/pages/ResourcesPage";
import SupportPage from "@/pages/SupportPage";

// Authentication and User Experience pages
import AuthPage from "@/pages/auth-page";
import DashboardPage from "@/pages/DashboardPage";
import OnboardingPage from "@/pages/OnboardingPage";
import IntegrationPage from "@/pages/IntegrationPage";

// Inventory Section
import InventoryPage from "@/pages/InventoryPage";
import InventoryFeaturesPage from "@/pages/InventoryFeaturesPage";
import InventoryPricingPage from "@/pages/InventoryPricingPage";
import InventoryIntegrationsPage from "@/pages/InventoryIntegrationsPage";
import InventoryCaseStudiesPage from "@/pages/InventoryCaseStudiesPage";

function Router() {
  return (
    <Switch>
      {/* Public routes */}
      <Route path="/" component={HomePage} />
      <Route path="/pricing" component={PricingPage} />
      <Route path="/products/:productId" component={ProductPage} />
      <Route path="/solutions/:solutionId" component={SolutionPage} />
      <Route path="/resources" component={ResourcesPage} />
      <Route path="/support" component={SupportPage} />
      <Route path="/auth" component={AuthPage} />
      
      {/* Inventory Routes */}
      <Route path="/inventory" component={InventoryPage} />
      <Route path="/inventory/features" component={InventoryFeaturesPage} />
      <Route path="/inventory/pricing" component={InventoryPricingPage} />
      <Route path="/inventory/integrations" component={InventoryIntegrationsPage} />
      <Route path="/inventory/case-studies" component={InventoryCaseStudiesPage} />
      
      {/* Protected routes */}
      <ProtectedRoute path="/dashboard" component={DashboardPage} />
      <ProtectedRoute path="/onboarding" component={OnboardingPage} />
      <ProtectedRoute path="/integrations" component={IntegrationPage} />
      <ProtectedRoute path="/integrations/:id" component={IntegrationPage} />
      
      {/* 404 - Not Found */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
