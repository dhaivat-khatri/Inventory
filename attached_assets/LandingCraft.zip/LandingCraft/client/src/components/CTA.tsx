import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const CTA = () => {
  return (
    <section className="py-16 bg-primary-700 text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-4">Ready to transform your business?</h2>
        <p className="text-xl text-primary-100 max-w-3xl mx-auto mb-8">Join thousands of companies using BizSuite to streamline operations, boost productivity, and drive growth.</p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Button variant="secondary" size="lg" asChild>
            <Link href="/register">Start Free Trial</Link>
          </Button>
          <Button 
            variant="outline" 
            size="lg" 
            className="bg-transparent border border-white text-white hover:bg-white/10"
            asChild
          >
            <Link href="/demo">Schedule Demo</Link>
          </Button>
        </div>
        <p className="mt-4 text-sm text-primary-200">No credit card required. 14-day free trial.</p>
      </div>
    </section>
  );
};

export default CTA;
