import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const features = [
  {
    id: 1,
    title: "Seamless Integration",
    description: "All applications work together out of the box, with no complex setup required."
  },
  {
    id: 2,
    title: "Centralized Data",
    description: "Access all your business information in one place, with consistent reporting across modules."
  },
  {
    id: 3,
    title: "Consistent Experience",
    description: "Enjoy the same intuitive interface across all applications, reducing training time."
  }
];

const FeatureHighlight = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0 md:pr-12">
            <img 
              src="https://images.unsplash.com/photo-1531973576160-7125cd663d86?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
              alt="Dashboard showcase" 
              className="rounded-lg shadow-lg"
              width="600"
              height="400"
            />
          </div>
          <div className="md:w-1/2">
            <h2 className="text-3xl font-bold mb-4">Everything in one unified platform</h2>
            <p className="text-lg text-gray-600 mb-6">Stop juggling multiple tools. Our integrated platform connects all your business functions, eliminating data silos and providing a single source of truth.</p>
            
            <div className="space-y-4">
              {features.map((feature) => (
                <div key={feature.id} className="flex">
                  <div className="flex-shrink-0 mr-4">
                    <div className="h-8 w-8 bg-primary-100 text-primary rounded-full flex items-center justify-center">
                      <Check className="h-4 w-4" />
                    </div>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">{feature.title}</h3>
                    <p className="text-gray-600">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-8">
              <Button asChild>
                <Link href="/demo">See it in action</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeatureHighlight;
