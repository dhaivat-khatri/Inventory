import { Link } from "wouter";
import { 
  Facebook, 
  Twitter, 
  Linkedin, 
  Instagram
} from "lucide-react";

const Footer = () => {
  const year = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-800 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          <div className="col-span-2">
            <Link href="/" className="text-white font-bold text-2xl mb-4 inline-block">
              <span className="text-primary-400">Biz</span>Suite
            </Link>
            <p className="text-gray-300 mb-4">Comprehensive business solutions to help you manage, grow, and succeed.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white" aria-label="Twitter">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white" aria-label="Facebook">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white" aria-label="LinkedIn">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white" aria-label="Instagram">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold text-lg mb-4">Products</h4>
            <ul className="space-y-2">
              <li><Link href="/products/crm" className="text-gray-300 hover:text-white">CRM</Link></li>
              <li><Link href="/products/email-marketing" className="text-gray-300 hover:text-white">Email Marketing</Link></li>
              <li><Link href="/products/finance" className="text-gray-300 hover:text-white">Finance</Link></li>
              <li><Link href="/products/hr" className="text-gray-300 hover:text-white">HR Management</Link></li>
              <li><Link href="/products/project-management" className="text-gray-300 hover:text-white">Project Management</Link></li>
              <li><Link href="/products/customer-support" className="text-gray-300 hover:text-white">Customer Support</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-lg mb-4">Solutions</h4>
            <ul className="space-y-2">
              <li><Link href="/solutions/financial-services" className="text-gray-300 hover:text-white">Financial Services</Link></li>
              <li><Link href="/solutions/healthcare" className="text-gray-300 hover:text-white">Healthcare</Link></li>
              <li><Link href="/solutions/small-business" className="text-gray-300 hover:text-white">Small Business</Link></li>
              <li><Link href="/solutions/enterprise" className="text-gray-300 hover:text-white">Enterprise</Link></li>
              <li><Link href="/solutions/sales-teams" className="text-gray-300 hover:text-white">Sales Teams</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-lg mb-4">Resources & Support</h4>
            <ul className="space-y-2">
              <li><Link href="/resources" className="text-gray-300 hover:text-white">Resource Center</Link></li>
              <li><Link href="/support" className="text-gray-300 hover:text-white">Support</Link></li>
              <li><Link href="/signin" className="text-gray-300 hover:text-white">Sign In</Link></li>
              <li><Link href="/register" className="text-gray-300 hover:text-white">Register</Link></li>
              <li><Link href="/contact" className="text-gray-300 hover:text-white">Contact Us</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-gray-700">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <p className="text-gray-400">© {year} BizSuite. All rights reserved.</p>
            </div>
            <div className="flex flex-wrap gap-4">
              <Link href="/terms" className="text-gray-400 hover:text-white">Terms</Link>
              <Link href="/privacy" className="text-gray-400 hover:text-white">Privacy</Link>
              <Link href="/security" className="text-gray-400 hover:text-white">Security</Link>
              <Link href="/cookies" className="text-gray-400 hover:text-white">Cookies</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
