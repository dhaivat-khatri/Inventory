import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  ChevronDown, 
  Menu,
  X
} from "lucide-react";
import { navItems, NavItem } from "@/utils/navItems";

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileSubmenus, setMobileSubmenus] = useState<{[key: string]: boolean}>({});
  const [location] = useLocation();

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const toggleMobileSubmenu = (key: string) => {
    setMobileSubmenus({
      ...mobileSubmenus,
      [key]: !mobileSubmenus[key]
    });
  };

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <nav className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex items-center py-4">
            <Link href="/" className="text-primary font-bold text-2xl">
              <span className="text-primary">Biz</span>Suite
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            {navItems.map((item, index) => (
              item.dropdown ? (
                <div key={index} className="relative group py-4">
                  <button className="flex items-center text-gray-700 hover:text-primary font-medium py-2">
                    {item.label} <ChevronDown className="ml-1 h-4 w-4" />
                  </button>
                  <div className="absolute left-0 top-full pt-2 w-64 bg-white shadow-lg rounded-md p-2 hidden group-hover:block z-50">
                    <div className="grid grid-cols-1 gap-1 max-h-[80vh] overflow-y-auto">
                      {item.children?.map((child, childIndex) => (
                        <Link 
                          key={childIndex} 
                          href={child.href} 
                          className="block px-4 py-2 text-sm text-gray-700 hover:bg-primary/10 rounded"
                        >
                          {child.label}
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <Link 
                  key={index} 
                  href={item.href || '/'} 
                  className={`text-gray-700 hover:text-primary font-medium py-4 ${location === item.href ? 'text-primary' : ''}`}
                >
                  {item.label}
                </Link>
              )
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="flex items-center space-x-4">
            <Link href="/signin" className="hidden md:inline-block text-gray-700 hover:text-primary font-medium">
              Sign In
            </Link>
            <Button asChild>
              <Link href="/register">Start Free</Link>
            </Button>
            
            {/* Mobile Menu Button */}
            <button 
              className="md:hidden text-gray-700" 
              onClick={toggleMobileMenu}
              aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </nav>
      </div>

      {/* Mobile Navigation */}
      <div className={`md:hidden bg-white shadow-lg ${mobileMenuOpen ? 'block' : 'hidden'}`}>
        <div className="px-4 py-2 space-y-1">
          {navItems.map((item, index) => (
            item.dropdown ? (
              <div key={index} className="py-2 border-b">
                <button 
                  className="flex items-center justify-between w-full text-left text-gray-700 font-medium" 
                  onClick={() => toggleMobileSubmenu(item.label)}
                >
                  {item.label} 
                  <ChevronDown className={`h-4 w-4 ml-1 transition-transform ${mobileSubmenus[item.label] ? 'rotate-180' : ''}`} />
                </button>
                <div className={`pl-4 mt-1 space-y-1 ${mobileSubmenus[item.label] ? 'block' : 'hidden'}`}>
                  {item.children?.map((child, childIndex) => (
                    <Link 
                      key={childIndex} 
                      href={child.href} 
                      className="block py-2 text-sm text-gray-700"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      {child.label}
                    </Link>
                  ))}
                </div>
              </div>
            ) : (
              <Link 
                key={index} 
                href={item.href || '/'} 
                className="block py-2 text-gray-700 border-b font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                {item.label}
              </Link>
            )
          ))}
          <Link 
            href="/signin" 
            className="block py-2 text-gray-700 border-b font-medium"
            onClick={() => setMobileMenuOpen(false)}
          >
            Sign In
          </Link>
          <Link 
            href="/register" 
            className="block py-2 text-center bg-primary text-white rounded-md mt-2 font-medium"
            onClick={() => setMobileMenuOpen(false)}
          >
            Start Free
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Header;
