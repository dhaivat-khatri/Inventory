import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const Hero = () => {
  return (
    <section className="bg-gradient-to-r from-primary to-primary-700 text-white py-20">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Run your entire business with <span className="text-primary-200">BizSuite</span></h1>
            <p className="text-xl mb-8 text-primary-100">All-in-one platform for CRM, marketing, finance, HR, and more. Everything you need to grow your business.</p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button variant="secondary" size="lg" asChild>
                <Link href="/register">Start Free Trial</Link>
              </Button>
              <Button variant="outline" size="lg" className="bg-transparent border border-white text-white hover:bg-white/10" asChild>
                <Link href="/demo">Watch Demo</Link>
              </Button>
            </div>
            <p className="mt-4 text-sm text-primary-100">No credit card required. 14-day free trial.</p>
          </div>
          <div className="md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
              alt="Business team using BizSuite platform" 
              className="rounded-lg shadow-xl"
              width="600"
              height="400"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
