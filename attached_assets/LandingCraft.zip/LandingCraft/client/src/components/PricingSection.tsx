import { useState } from "react";
import { Link } from "wouter";
import { Switch } from "@/components/ui/switch";
import { Check, X, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const pricingPlans = [
  {
    id: "free",
    name: "Free",
    description: "For individuals and small teams getting started",
    monthlyPrice: 0,
    annualPrice: 0,
    features: [
      { text: "Up to 3 users", included: true },
      { text: "Basic CRM", included: true },
      { text: "Email marketing (500 emails/month)", included: true },
      { text: "Basic reporting", included: true },
      { text: "Advanced features", included: false },
      { text: "Premium support", included: false },
    ],
    buttonText: "Get Started",
    buttonVariant: "outline" as const
  },
  {
    id: "standard",
    name: "Standard",
    description: "For growing businesses and teams",
    monthlyPrice: 25,
    annualPrice: 20,
    priceUnit: "/month per user",
    features: [
      { text: "Unlimited users", included: true },
      { text: "Full CRM functionality", included: true },
      { text: "Email marketing (10,000 emails/month)", included: true },
      { text: "Advanced reporting", included: true },
      { text: "Basic integrations", included: true },
      { text: "Premium support", included: false },
    ],
    buttonText: "Start Trial",
    buttonVariant: "default" as const
  },
  {
    id: "premium",
    name: "Premium",
    description: "For established businesses needing more",
    monthlyPrice: 49,
    annualPrice: 39,
    priceUnit: "/month per user",
    popular: true,
    features: [
      { text: "Unlimited users", included: true },
      { text: "Full CRM with automation", included: true },
      { text: "Email marketing (Unlimited)", included: true },
      { text: "Advanced reporting & analytics", included: true },
      { text: "All integrations", included: true },
      { text: "Premium support", included: true },
    ],
    buttonText: "Start Trial",
    buttonVariant: "default" as const
  },
  {
    id: "enterprise",
    name: "Enterprise",
    description: "For large organizations with custom needs",
    customPrice: true,
    features: [
      { text: "Unlimited users", included: true },
      { text: "Full platform access", included: true },
      { text: "Custom development", included: true },
      { text: "Dedicated account manager", included: true },
      { text: "SLA guarantees", included: true },
      { text: "24/7 priority support", included: true },
    ],
    buttonText: "Contact Sales",
    buttonVariant: "outline" as const,
    buttonColor: "primary" as const
  }
];

const PricingSection = () => {
  const [billingAnnual, setBillingAnnual] = useState(false);

  return (
    <section id="pricing" className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Simple, transparent pricing</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">Choose the plan that works best for your business. All plans include 14-day free trial.</p>
          
          <div className="flex justify-center items-center mt-8">
            <span className="text-gray-600 mr-3">Monthly</span>
            <Switch
              checked={billingAnnual}
              onCheckedChange={setBillingAnnual}
              id="billing-toggle"
            />
            <span className="text-gray-800 font-medium ml-3">
              Annual <span className="text-green-600 text-sm">(Save 20%)</span>
            </span>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {pricingPlans.map((plan) => (
            <div 
              key={plan.id} 
              className={`bg-white rounded-lg shadow-md border overflow-hidden ${
                plan.popular 
                  ? 'shadow-xl border-2 border-primary relative' 
                  : 'border-gray-200'
              }`}
            >
              {plan.popular && (
                <Badge className="absolute top-0 right-0 rounded-bl-lg rounded-tr-none">
                  Popular
                </Badge>
              )}
              <div className="p-6 border-b">
                <h3 className="font-bold text-2xl mb-2">{plan.name}</h3>
                <p className="text-gray-600 mb-4">{plan.description}</p>
                <div className="flex items-baseline">
                  {plan.customPrice ? (
                    <span className="text-3xl font-bold">Custom</span>
                  ) : (
                    <>
                      <span className="text-3xl font-bold">
                        ${billingAnnual ? plan.annualPrice : plan.monthlyPrice}
                      </span>
                      {plan.priceUnit && (
                        <span className="text-gray-600 ml-1">
                          {billingAnnual ? '/month per user, billed annually' : plan.priceUnit}
                        </span>
                      )}
                    </>
                  )}
                </div>
              </div>
              <div className="p-6">
                <ul className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      {feature.included ? (
                        <Check className="text-green-500 mt-1 mr-2 h-4 w-4 flex-shrink-0" />
                      ) : (
                        <X className="text-gray-400 mt-1 mr-2 h-4 w-4 flex-shrink-0" />
                      )}
                      <span className={feature.included ? '' : 'text-gray-400'}>
                        {feature.text}
                      </span>
                    </li>
                  ))}
                </ul>
                <div className="mt-6">
                  <Button 
                    variant={plan.buttonVariant} 
                    className={`w-full ${plan.buttonColor === 'primary' ? 'text-primary border-primary hover:bg-primary/10' : ''}`}
                    asChild
                  >
                    <Link href={plan.id === "enterprise" ? "/contact" : "/register"}>
                      {plan.buttonText}
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <h3 className="text-xl font-bold mb-4">Need help choosing the right plan?</h3>
          <p className="text-gray-600 mb-6">Our team can help you find the perfect solution for your business needs.</p>
          <Link 
            href="/consultation" 
            className="inline-flex items-center text-primary font-medium hover:text-primary-700"
          >
            Schedule a consultation <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
