import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { ProductIcons } from "@/lib/icons";

const products = [
  {
    id: 1,
    title: "CRM",
    icon: "users",
    description: "Build stronger customer relationships with a complete view of your customers, streamlined sales processes, and powerful analytics.",
    href: "/products/crm"
  },
  {
    id: 2,
    title: "Email Marketing",
    icon: "mail",
    description: "Create, send, and analyze email campaigns that drive engagement and conversions with our intuitive email marketing tools.",
    href: "/products/email-marketing"
  },
  {
    id: 3,
    title: "Finance",
    icon: "chart",
    description: "Simplify accounting, invoicing, expenses, and financial reporting with our comprehensive finance solutions.",
    href: "/products/finance"
  },
  {
    id: 4,
    title: "HR Management",
    icon: "user",
    description: "Manage the entire employee lifecycle from recruitment to retirement with our powerful HR tools.",
    href: "/products/hr"
  },
  {
    id: 5,
    title: "Project Management",
    icon: "tasks",
    description: "Plan, track, and deliver projects on time and within budget with our collaborative project management software.",
    href: "/products/project-management"
  },
  {
    id: 6,
    title: "Customer Support",
    icon: "headset",
    description: "Provide exceptional customer service with our help desk, live chat, and knowledge base solutions.",
    href: "/products/customer-support"
  }
];

const ProductShowcase = () => {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">All the tools you need to succeed</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">Our comprehensive suite of business applications helps you streamline operations, increase productivity, and drive growth.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <div 
              key={product.id}
              className="bg-white rounded-lg shadow-md hover:shadow-lg transition p-6 border border-gray-100 h-full flex flex-col"
            >
              <div className="mb-4 text-primary">
                {ProductIcons[product.icon]}
              </div>
              <h3 className="text-xl font-bold mb-2">{product.title}</h3>
              <p className="text-gray-600 mb-4 flex-grow">{product.description}</p>
              <Link 
                href={product.href} 
                className="text-primary font-medium hover:text-primary-700 inline-flex items-center"
              >
                Learn more <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductShowcase;
