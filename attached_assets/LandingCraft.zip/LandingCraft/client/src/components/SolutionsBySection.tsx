import { useState } from "react";
import { ArrowRight } from "lucide-react";
import { Link } from "wouter";

// Solutions data
const solutionsData = {
  industry: [
    { id: 1, title: "Financial Services", description: "Secure, compliant solutions for banks, insurance companies, and financial institutions.", href: "/solutions/financial-services" },
    { id: 2, title: "Healthcare", description: "HIPAA-compliant tools for healthcare providers, hospitals, and medical practices.", href: "/solutions/healthcare" },
    { id: 3, title: "Manufacturing", description: "Streamline operations and optimize production with specialized tools for manufacturers.", href: "/solutions/manufacturing" },
    { id: 4, title: "Retail", description: "Omnichannel solutions for retailers to manage inventory, sales, and customer relationships.", href: "/solutions/retail" },
    { id: 5, title: "Technology", description: "Tools for SaaS companies, IT service providers, and technology startups.", href: "/solutions/technology" },
    { id: 6, title: "Education", description: "Solutions for schools, universities, and educational institutions.", href: "/solutions/education" }
  ],
  size: [
    { id: 1, title: "Small Business", description: "Affordable, easy-to-use solutions for small businesses with 1-50 employees.", href: "/solutions/small-business" },
    { id: 2, title: "Mid-Market", description: "Scalable solutions for growing businesses with 50-500 employees.", href: "/solutions/mid-market" },
    { id: 3, title: "Enterprise", description: "Robust, customizable solutions for large organizations with 500+ employees.", href: "/solutions/enterprise" }
  ],
  role: [
    { id: 1, title: "Sales Teams", description: "Tools to help sales teams close more deals and manage relationships.", href: "/solutions/sales-teams" },
    { id: 2, title: "Marketing Teams", description: "Solutions for creating campaigns, analyzing results, and growing your audience.", href: "/solutions/marketing-teams" },
    { id: 3, title: "IT Departments", description: "Tools for IT professionals to manage infrastructure, support, and security.", href: "/solutions/it-departments" },
    { id: 4, title: "HR & People Ops", description: "Solutions for recruiting, onboarding, and managing employee experience.", href: "/solutions/hr-people-ops" }
  ]
};

const SolutionsBySection = () => {
  const [activeTab, setActiveTab] = useState<'industry' | 'size' | 'role'>('industry');

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Solutions tailored to your needs</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">Whether you're a small business or an enterprise, we have solutions designed for your specific requirements.</p>
        </div>
        
        {/* Tab Controls */}
        <div className="flex flex-wrap justify-center mb-8 border-b">
          <button 
            className={`text-lg font-medium px-6 py-3 border-b-2 ${activeTab === 'industry' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
            onClick={() => setActiveTab('industry')}
          >
            By Industry
          </button>
          <button 
            className={`text-lg font-medium px-6 py-3 border-b-2 ${activeTab === 'size' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
            onClick={() => setActiveTab('size')}
          >
            By Business Size
          </button>
          <button 
            className={`text-lg font-medium px-6 py-3 border-b-2 ${activeTab === 'role' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
            onClick={() => setActiveTab('role')}
          >
            By Role
          </button>
        </div>
        
        {/* Tab Content */}
        <div className={activeTab === 'industry' ? 'block' : 'hidden'}>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {solutionsData.industry.map((solution) => (
              <div key={solution.id} className="bg-white rounded-lg shadow p-6 border border-gray-100">
                <h3 className="text-xl font-bold mb-3">{solution.title}</h3>
                <p className="text-gray-600 mb-4">{solution.description}</p>
                <Link 
                  href={solution.href} 
                  className="text-primary font-medium hover:text-primary-700 inline-flex items-center"
                >
                  Learn more <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>
            ))}
          </div>
        </div>
        
        <div className={activeTab === 'size' ? 'block' : 'hidden'}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {solutionsData.size.map((solution) => (
              <div key={solution.id} className="bg-white rounded-lg shadow p-6 border border-gray-100">
                <h3 className="text-xl font-bold mb-3">{solution.title}</h3>
                <p className="text-gray-600 mb-4">{solution.description}</p>
                <Link 
                  href={solution.href} 
                  className="text-primary font-medium hover:text-primary-700 inline-flex items-center"
                >
                  Learn more <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>
            ))}
          </div>
        </div>
        
        <div className={activeTab === 'role' ? 'block' : 'hidden'}>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {solutionsData.role.map((solution) => (
              <div key={solution.id} className="bg-white rounded-lg shadow p-6 border border-gray-100">
                <h3 className="text-xl font-bold mb-3">{solution.title}</h3>
                <p className="text-gray-600 mb-4">{solution.description}</p>
                <Link 
                  href={solution.href} 
                  className="text-primary font-medium hover:text-primary-700 inline-flex items-center"
                >
                  Learn more <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SolutionsBySection;
