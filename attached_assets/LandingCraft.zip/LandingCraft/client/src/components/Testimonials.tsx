import { useState, useRef, useEffect } from "react";
import { ChevronLeft, ChevronRight, Star } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "James Wilson",
    role: "CEO, TechStart Inc.",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
    stars: 5,
    testimonial: "BizSuite transformed our operations. We've increased sales by 35% and cut administrative time in half. The integrated platform means our teams are always on the same page."
  },
  {
    id: 2,
    name: "Sarah Johnson",
    role: "Marketing Director, Bloom Retail",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
    stars: 5,
    testimonial: "The email marketing and CRM integration is seamless. We've seen a 40% increase in campaign engagement since switching to BizSuite. The analytics help us make data-driven decisions."
  },
  {
    id: 3,
    name: "Michael Chang",
    role: "CFO, Horizon Healthcare",
    image: "https://images.unsplash.com/photo-1522529599102-193c0d76b5b6?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
    stars: 4.5,
    testimonial: "The finance module has revolutionized our accounting processes. Automated invoicing and expense tracking save us countless hours each month. The reporting features are exceptional."
  }
];

const Testimonials = () => {
  const carouselRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const checkScrollable = () => {
    if (carouselRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = carouselRef.current;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10); // small buffer for rounding errors
    }
  };

  useEffect(() => {
    const carousel = carouselRef.current;
    if (carousel) {
      carousel.addEventListener('scroll', checkScrollable);
      // Initial check
      checkScrollable();
      
      return () => {
        carousel.removeEventListener('scroll', checkScrollable);
      };
    }
  }, []);

  const scrollLeft = () => {
    if (carouselRef.current) {
      carouselRef.current.scrollBy({ left: -carouselRef.current.offsetWidth, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (carouselRef.current) {
      carouselRef.current.scrollBy({ left: carouselRef.current.offsetWidth, behavior: 'smooth' });
    }
  };

  const renderStars = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    return (
      <div className="flex text-yellow-400">
        {[...Array(fullStars)].map((_, i) => (
          <Star key={i} className="h-4 w-4 fill-current" />
        ))}
        {hasHalfStar && (
          <div className="relative">
            <Star className="h-4 w-4 text-gray-300" />
            <div className="absolute top-0 left-0 overflow-hidden w-1/2">
              <Star className="h-4 w-4 fill-current text-yellow-400" />
            </div>
          </div>
        )}
        {[...Array(5 - Math.ceil(rating))].map((_, i) => (
          <Star key={fullStars + (hasHalfStar ? 1 : 0) + i} className="h-4 w-4 text-gray-300" />
        ))}
      </div>
    );
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">What our customers say</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">See how businesses of all sizes achieve their goals with BizSuite.</p>
        </div>
        
        <div className="relative">
          <div 
            ref={carouselRef} 
            className="flex overflow-x-auto space-x-6 pb-6 scroll-smooth scrollbar-hide snap-x snap-mandatory"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {testimonials.map((testimonial) => (
              <div 
                key={testimonial.id} 
                className="snap-center flex-shrink-0 w-full md:w-1/2 lg:w-1/3"
              >
                <div className="bg-white rounded-lg shadow-md p-8 h-full">
                  <div className="flex items-center mb-4">
                    <img 
                      src={testimonial.image} 
                      alt={testimonial.name} 
                      className="w-12 h-12 rounded-full object-cover mr-4"
                    />
                    <div>
                      <h4 className="font-semibold">{testimonial.name}</h4>
                      <p className="text-gray-600 text-sm">{testimonial.role}</p>
                    </div>
                  </div>
                  <div className="mb-4">
                    {renderStars(testimonial.stars)}
                  </div>
                  <p className="text-gray-700 italic">"{testimonial.testimonial}"</p>
                </div>
              </div>
            ))}
          </div>
          
          <button 
            className={`absolute left-0 top-1/2 transform -translate-y-1/2 bg-white rounded-full shadow-md p-3 text-gray-600 hover:text-primary focus:outline-none hidden md:block ${!canScrollLeft ? 'opacity-50 cursor-not-allowed' : ''}`}
            onClick={scrollLeft}
            disabled={!canScrollLeft}
            aria-label="Previous testimonial"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          
          <button 
            className={`absolute right-0 top-1/2 transform -translate-y-1/2 bg-white rounded-full shadow-md p-3 text-gray-600 hover:text-primary focus:outline-none hidden md:block ${!canScrollRight ? 'opacity-50 cursor-not-allowed' : ''}`}
            onClick={scrollRight}
            disabled={!canScrollRight}
            aria-label="Next testimonial"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
        
        <div className="text-center mt-8">
          <Link
            href="/customer-stories"
            className="text-primary font-medium hover:text-primary-700 inline-flex items-center"
          >
            View all customer stories <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
};

import { ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default Testimonials;
