const TrustedBy = () => {
  return (
    <section className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <p className="text-center text-gray-500 font-medium mb-8">Trusted by 10,000+ businesses worldwide</p>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 justify-items-center items-center">
          {/* Using gray placeholders for company logos */}
          <div className="h-8 w-24 bg-gray-300 rounded opacity-70"></div>
          <div className="h-8 w-28 bg-gray-300 rounded opacity-70"></div>
          <div className="h-8 w-20 bg-gray-300 rounded opacity-70"></div>
          <div className="h-8 w-32 bg-gray-300 rounded opacity-70"></div>
          <div className="h-8 w-24 bg-gray-300 rounded opacity-70"></div>
          <div className="h-8 w-28 bg-gray-300 rounded opacity-70"></div>
        </div>
      </div>
    </section>
  );
};

export default TrustedBy;
