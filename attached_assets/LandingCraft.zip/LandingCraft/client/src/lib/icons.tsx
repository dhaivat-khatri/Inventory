import { 
  Users, 
  Mail, 
  BarChart3, 
  UserRound, 
  ListTodo, 
  Headphones 
} from "lucide-react";

export const ProductIcons: {[key: string]: JSX.Element} = {
  users: <Users className="h-6 w-6" />,
  mail: <Mail className="h-6 w-6" />,
  chart: <BarChart3 className="h-6 w-6" />,
  user: <UserRound className="h-6 w-6" />,
  tasks: <ListTodo className="h-6 w-6" />,
  headset: <Headphones className="h-6 w-6" />
};
