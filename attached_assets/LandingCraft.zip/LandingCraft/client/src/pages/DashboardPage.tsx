import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import {
  BarChart3, ShoppingBag, ArrowUpRight, Package, Settings, Award, 
  ChevronRight, Plus, Upload, RefreshCcw, User, Bell, LogOut
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/hooks/use-toast";

const DashboardPage = () => {
  const [location, setLocation] = useLocation();
  
  // Query for user data
  const { data: user, isLoading: userLoading, error: userError } = useQuery({
    queryKey: ['/api/auth/me'],
    retry: false,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
  
  // Query for user's integrations
  const { data: integrations, isLoading: integrationsLoading } = useQuery({
    queryKey: ['/api/integrations'],
    enabled: !!user,
  });
  
  // Query for user's products
  const { data: products, isLoading: productsLoading } = useQuery({
    queryKey: ['/api/products'],
    enabled: !!user,
  });
  
  // Query for user's achievements
  const { data: achievements, isLoading: achievementsLoading } = useQuery({
    queryKey: ['/api/achievements'],
    enabled: !!user,
  });
  
  // Query for user's engagement points
  const { data: points, isLoading: pointsLoading } = useQuery({
    queryKey: ['/api/engagement-points'],
    enabled: !!user,
  });
  
  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('/api/auth/logout', {
        method: 'POST'
      });
    },
    onSuccess: () => {
      // Clear all queries from the cache
      queryClient.clear();
      // Redirect to home page
      setLocation('/');
      toast({
        title: "Logged out successfully",
        variant: "default",
      });
    },
  });
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  // Redirect to login page if not authenticated
  useEffect(() => {
    if (userError) {
      setLocation('/signin');
    }
  }, [userError, setLocation]);
  
  // Redirect to onboarding if onboarding not completed
  useEffect(() => {
    if (user && !user.onboardingCompleted) {
      setLocation('/onboarding');
    }
  }, [user, setLocation]);
  
  if (userLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-500">Loading your dashboard...</p>
        </div>
      </div>
    );
  }
  
  if (userError) {
    return null; // We'll redirect in the useEffect
  }
  
  const availableIntegrations = [
    { id: 'shopify', name: 'Shopify', category: 'ecommerce', logo: 'S', color: 'bg-green-100 text-green-800' },
    { id: 'amazon', name: 'Amazon', category: 'ecommerce', logo: 'A', color: 'bg-orange-100 text-orange-800' },
    { id: 'woocommerce', name: 'WooCommerce', category: 'ecommerce', logo: 'W', color: 'bg-purple-100 text-purple-800' },
    { id: 'quickbooks', name: 'QuickBooks', category: 'accounting', logo: 'Q', color: 'bg-blue-100 text-blue-800' },
    { id: 'xero', name: 'Xero', category: 'accounting', logo: 'X', color: 'bg-indigo-100 text-indigo-800' },
    { id: 'fedex', name: 'FedEx', category: 'shipping', logo: 'F', color: 'bg-purple-100 text-purple-800' },
    { id: 'ups', name: 'UPS', category: 'shipping', logo: 'U', color: 'bg-yellow-100 text-yellow-800' },
    { id: 'zoho-crm', name: 'Zoho CRM', category: 'crm', logo: 'Z', color: 'bg-red-100 text-red-800' },
  ];
  
  // Check if an integration is connected
  const isConnected = (id: string) => {
    if (!integrations) return false;
    return integrations.some((integration: any) => integration.provider === id);
  };
  
  // Get the total number of engagement points
  const totalPoints = points?.points || 0;
  
  // Get recent achievements (up to 3)
  const recentAchievements = achievements?.slice(0, 3) || [];
  
  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="hidden md:flex w-64 flex-col bg-white border-r">
        <div className="h-16 border-b flex items-center px-4">
          <Link href="/" className="text-primary font-bold text-2xl">
            <span className="text-primary">Biz</span>Suite
          </Link>
        </div>
        
        <div className="flex-1 overflow-y-auto py-4">
          <nav className="space-y-1 px-2">
            <Link 
              href="/dashboard" 
              className="flex items-center px-2 py-2 text-sm font-medium rounded-md bg-primary-50 text-primary"
            >
              <BarChart3 className="mr-3 h-5 w-5" />
              Dashboard
            </Link>
            
            <Link 
              href="/inventory-manager" 
              className="flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            >
              <Package className="mr-3 h-5 w-5" />
              Inventory Manager
            </Link>
            
            <Link 
              href="/integrations" 
              className="flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            >
              <RefreshCcw className="mr-3 h-5 w-5" />
              Integrations
            </Link>
            
            <Link 
              href="/settings" 
              className="flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            >
              <Settings className="mr-3 h-5 w-5" />
              Settings
            </Link>
          </nav>
        </div>
        
        <div className="border-t p-4">
          <div className="flex items-center">
            <div className="h-9 w-9 bg-primary-100 rounded-full flex items-center justify-center text-primary font-semibold">
              {user?.fullName?.charAt(0) || 'U'}
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium">{user?.fullName}</p>
              <p className="text-xs text-gray-500 truncate">{user?.email}</p>
            </div>
          </div>
          
          <Button 
            variant="outline" 
            className="w-full mt-4" 
            size="sm" 
            onClick={handleLogout}
          >
            <LogOut className="h-4 w-4 mr-2" />
            Log out
          </Button>
        </div>
      </div>
      
      {/* Main content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="h-16 border-b bg-white flex items-center justify-between px-4 md:px-6">
          <div className="md:hidden">
            <Link href="/" className="text-primary font-bold text-2xl">
              <span className="text-primary">Biz</span>Suite
            </Link>
          </div>
          
          <div className="flex items-center space-x-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Bell className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Notifications</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <div className="py-4 px-2 text-center text-sm text-gray-500">
                  No new notifications
                </div>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-9 w-9 rounded-full">
                  <div className="h-9 w-9 bg-primary-100 rounded-full flex items-center justify-center text-primary font-semibold">
                    {user?.fullName?.charAt(0) || 'U'}
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/profile">
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/settings">
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>
        
        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-gray-50">
          <div className="max-w-7xl mx-auto">
            <div className="mb-6">
              <h1 className="text-2xl font-bold">Welcome back, {user?.fullName?.split(' ')[0] || 'User'}</h1>
              <p className="text-gray-500">Here's what's happening with your inventory today.</p>
            </div>
            
            {/* Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500">Total Products</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{productsLoading ? '...' : products?.length || 0}</div>
                  <p className="text-sm text-gray-500 mt-1">
                    {productsLoading ? 'Loading...' : products?.length === 0 ? 'No products added yet' : 'Across all channels'}
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500">Connected Integrations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{integrationsLoading ? '...' : integrations?.length || 0}</div>
                  <p className="text-sm text-gray-500 mt-1">
                    {integrationsLoading ? 'Loading...' : 
                      integrations?.length === 0 ? 'No integrations connected' : 
                      `${integrations?.length} ${integrations?.length === 1 ? 'platform' : 'platforms'} connected`}
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500">Engagement Points</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{pointsLoading ? '...' : totalPoints}</div>
                  <p className="text-sm text-gray-500 mt-1">
                    {pointsLoading ? 'Loading...' : totalPoints < 50 ? 'Just getting started!' : 
                    totalPoints < 100 ? 'Making good progress!' : 'Power user status!'}
                  </p>
                </CardContent>
              </Card>
            </div>
            
            {/* Main Dashboard Content */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                {/* Recent Products */}
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle>Recent Products</CardTitle>
                      <Button variant="ghost" size="sm" asChild>
                        <Link href="/inventory-manager" className="flex items-center">
                          View all
                          <ChevronRight className="ml-1 h-4 w-4" />
                        </Link>
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {productsLoading ? (
                      <div className="text-center py-8">
                        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
                        <p className="text-gray-500">Loading products...</p>
                      </div>
                    ) : products?.length > 0 ? (
                      <div className="space-y-4">
                        {products.slice(0, 5).map((product: any) => (
                          <div key={product.id} className="flex items-center p-3 bg-gray-50 rounded-lg">
                            <div className="h-10 w-10 bg-gray-200 rounded flex items-center justify-center text-gray-500 mr-3">
                              <ShoppingBag className="h-5 w-5" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium truncate">{product.name}</p>
                              <p className="text-xs text-gray-500">SKU: {product.sku}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-sm font-medium">${(product.price / 100).toFixed(2)}</p>
                              <p className="text-xs text-gray-500">Qty: {product.quantity}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <ShoppingBag className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">No products yet</h3>
                        <p className="text-gray-500 mb-6">Start adding your products to manage inventory</p>
                        <Button asChild>
                          <Link href="/inventory-manager">
                            <Plus className="mr-2 h-4 w-4" /> Add Product
                          </Link>
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                {/* Achievements */}
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle>Recent Achievements</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {achievementsLoading ? (
                      <div className="text-center py-8">
                        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
                        <p className="text-gray-500">Loading achievements...</p>
                      </div>
                    ) : recentAchievements.length > 0 ? (
                      <div className="space-y-4">
                        {recentAchievements.map((achievement: any) => (
                          <div key={achievement.id} className="flex items-center p-3 bg-gray-50 rounded-lg">
                            <div className="h-10 w-10 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-600 mr-3">
                              <Award className="h-5 w-5" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium">{achievement.achievementName}</p>
                              <p className="text-xs text-gray-500">{new Date(achievement.achievedAt).toLocaleDateString()}</p>
                            </div>
                            <div className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                              +{achievement.pointsAwarded} points
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <Award className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">No achievements yet</h3>
                        <p className="text-gray-500">Complete tasks to earn achievements and points</p>
                      </div>
                    )}
                    
                    {totalPoints > 0 && (
                      <div className="mt-6">
                        <div className="flex items-center justify-between mb-2">
                          <p className="text-sm font-medium">Progress to next level</p>
                          <p className="text-sm font-medium">{totalPoints}/200</p>
                        </div>
                        <Progress value={(totalPoints / 200) * 100} className="h-2" />
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
              
              <div className="space-y-6">
                {/* Integrations */}
                <Card>
                  <CardHeader>
                    <CardTitle>Integrations</CardTitle>
                    <CardDescription>Connect with your favorite platforms</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {integrationsLoading ? (
                      <div className="text-center py-8">
                        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
                        <p className="text-gray-500">Loading integrations...</p>
                      </div>
                    ) : (
                      <Tabs defaultValue="all" className="w-full">
                        <TabsList className="grid grid-cols-4 mb-4">
                          <TabsTrigger value="all">All</TabsTrigger>
                          <TabsTrigger value="ecommerce">Shop</TabsTrigger>
                          <TabsTrigger value="accounting">Finance</TabsTrigger>
                          <TabsTrigger value="shipping">Ship</TabsTrigger>
                        </TabsList>
                        
                        <TabsContent value="all" className="mt-0">
                          <div className="space-y-3">
                            {availableIntegrations.map(integration => (
                              <div key={integration.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                <div className="flex items-center">
                                  <div className={`h-8 w-8 ${integration.color} rounded-full flex items-center justify-center mr-3`}>
                                    {integration.logo}
                                  </div>
                                  <div>
                                    <p className="text-sm font-medium">{integration.name}</p>
                                    <p className="text-xs text-gray-500 capitalize">{integration.category}</p>
                                  </div>
                                </div>
                                {isConnected(integration.id) ? (
                                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                    Connected
                                  </Badge>
                                ) : (
                                  <Button variant="ghost" size="sm" asChild>
                                    <Link href={`/integrations/${integration.id}`}>
                                      Connect
                                    </Link>
                                  </Button>
                                )}
                              </div>
                            ))}
                          </div>
                        </TabsContent>
                        
                        <TabsContent value="ecommerce" className="mt-0">
                          <div className="space-y-3">
                            {availableIntegrations
                              .filter(i => i.category === 'ecommerce')
                              .map(integration => (
                                <div key={integration.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                  <div className="flex items-center">
                                    <div className={`h-8 w-8 ${integration.color} rounded-full flex items-center justify-center mr-3`}>
                                      {integration.logo}
                                    </div>
                                    <div>
                                      <p className="text-sm font-medium">{integration.name}</p>
                                      <p className="text-xs text-gray-500 capitalize">{integration.category}</p>
                                    </div>
                                  </div>
                                  {isConnected(integration.id) ? (
                                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                      Connected
                                    </Badge>
                                  ) : (
                                    <Button variant="ghost" size="sm" asChild>
                                      <Link href={`/integrations/${integration.id}`}>
                                        Connect
                                      </Link>
                                    </Button>
                                  )}
                                </div>
                            ))}
                          </div>
                        </TabsContent>
                        
                        <TabsContent value="accounting" className="mt-0">
                          <div className="space-y-3">
                            {availableIntegrations
                              .filter(i => i.category === 'accounting')
                              .map(integration => (
                                <div key={integration.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                  <div className="flex items-center">
                                    <div className={`h-8 w-8 ${integration.color} rounded-full flex items-center justify-center mr-3`}>
                                      {integration.logo}
                                    </div>
                                    <div>
                                      <p className="text-sm font-medium">{integration.name}</p>
                                      <p className="text-xs text-gray-500 capitalize">{integration.category}</p>
                                    </div>
                                  </div>
                                  {isConnected(integration.id) ? (
                                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                      Connected
                                    </Badge>
                                  ) : (
                                    <Button variant="ghost" size="sm" asChild>
                                      <Link href={`/integrations/${integration.id}`}>
                                        Connect
                                      </Link>
                                    </Button>
                                  )}
                                </div>
                            ))}
                          </div>
                        </TabsContent>
                        
                        <TabsContent value="shipping" className="mt-0">
                          <div className="space-y-3">
                            {availableIntegrations
                              .filter(i => i.category === 'shipping')
                              .map(integration => (
                                <div key={integration.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                  <div className="flex items-center">
                                    <div className={`h-8 w-8 ${integration.color} rounded-full flex items-center justify-center mr-3`}>
                                      {integration.logo}
                                    </div>
                                    <div>
                                      <p className="text-sm font-medium">{integration.name}</p>
                                      <p className="text-xs text-gray-500 capitalize">{integration.category}</p>
                                    </div>
                                  </div>
                                  {isConnected(integration.id) ? (
                                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                      Connected
                                    </Badge>
                                  ) : (
                                    <Button variant="ghost" size="sm" asChild>
                                      <Link href={`/integrations/${integration.id}`}>
                                        Connect
                                      </Link>
                                    </Button>
                                  )}
                                </div>
                            ))}
                          </div>
                        </TabsContent>
                      </Tabs>
                    )}
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full" asChild>
                      <Link href="/integrations">
                        <span>View All Integrations</span>
                        <ArrowUpRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
                
                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button className="w-full justify-start" asChild>
                      <Link href="/inventory-manager/add">
                        <Plus className="mr-2 h-4 w-4" /> Add New Product
                      </Link>
                    </Button>
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/import">
                        <Upload className="mr-2 h-4 w-4" /> Import Products
                      </Link>
                    </Button>
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/integrations/add">
                        <RefreshCcw className="mr-2 h-4 w-4" /> Connect Integration
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default DashboardPage;