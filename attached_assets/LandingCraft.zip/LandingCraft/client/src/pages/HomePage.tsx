import Header from "@/components/Header";
import Hero from "@/components/Hero";
import TrustedBy from "@/components/TrustedBy";
import ProductShowcase from "@/components/ProductShowcase";
import FeatureHighlight from "@/components/FeatureHighlight";
import SolutionsBySection from "@/components/SolutionsBySection";
import Testimonials from "@/components/Testimonials";
import PricingSection from "@/components/PricingSection";
import CTA from "@/components/CTA";
import Footer from "@/components/Footer";

const HomePage = () => {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <TrustedBy />
        <ProductShowcase />
        <FeatureHighlight />
        <SolutionsBySection />
        <Testimonials />
        <PricingSection />
        <CTA />
      </main>
      <Footer />
    </>
  );
};

export default HomePage;
