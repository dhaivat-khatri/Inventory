import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation, useRoute, Link } from "wouter";
import { ArrowLeft, ChevronRight, Loader2, Check } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";

// Mock integration configs for different platforms
const integrationConfigs = {
  shopify: {
    name: "Shopify",
    description: "Connect your Shopify store to sync products, inventory, and orders.",
    color: "bg-green-100 text-green-800",
    logo: "S",
    fields: [
      { name: "apiKey", label: "API Key", type: "text", required: true },
      { name: "apiSecret", label: "API Secret", type: "password", required: true },
      { name: "shopUrl", label: "Shop URL", type: "text", required: true, 
        placeholder: "your-store.myshopify.com" }
    ]
  },
  amazon: {
    name: "Amazon",
    description: "Connect your Amazon Seller account to manage inventory across marketplaces.",
    color: "bg-orange-100 text-orange-800",
    logo: "A",
    fields: [
      { name: "sellerId", label: "Seller ID", type: "text", required: true },
      { name: "accessKey", label: "Access Key", type: "text", required: true },
      { name: "secretKey", label: "Secret Key", type: "password", required: true },
      { name: "marketplaceId", label: "Marketplace ID", type: "text", required: true }
    ]
  },
  woocommerce: {
    name: "WooCommerce",
    description: "Connect your WooCommerce store to synchronize inventory and products.",
    color: "bg-purple-100 text-purple-800",
    logo: "W",
    fields: [
      { name: "siteUrl", label: "Store URL", type: "text", required: true, 
        placeholder: "https://your-store.com" },
      { name: "consumerKey", label: "Consumer Key", type: "text", required: true },
      { name: "consumerSecret", label: "Consumer Secret", type: "password", required: true }
    ]
  },
  quickbooks: {
    name: "QuickBooks",
    description: "Connect QuickBooks to sync your financial data and inventory transactions.",
    color: "bg-blue-100 text-blue-800",
    logo: "Q",
    fields: [
      { name: "clientId", label: "Client ID", type: "text", required: true },
      { name: "clientSecret", label: "Client Secret", type: "password", required: true },
      { name: "realmId", label: "Realm ID", type: "text", required: true }
    ]
  },
  xero: {
    name: "Xero",
    description: "Connect Xero accounting to manage financial aspects of your inventory.",
    color: "bg-indigo-100 text-indigo-800",
    logo: "X",
    fields: [
      { name: "clientId", label: "Client ID", type: "text", required: true },
      { name: "clientSecret", label: "Client Secret", type: "password", required: true }
    ]
  },
  fedex: {
    name: "FedEx",
    description: "Connect FedEx to automate shipping labels and tracking for your orders.",
    color: "bg-purple-100 text-purple-800",
    logo: "F",
    fields: [
      { name: "accountNumber", label: "Account Number", type: "text", required: true },
      { name: "apiKey", label: "API Key", type: "text", required: true },
      { name: "password", label: "Password", type: "password", required: true },
      { name: "meterNumber", label: "Meter Number", type: "text", required: true }
    ]
  },
  ups: {
    name: "UPS",
    description: "Connect UPS to streamline shipping operations and print labels.",
    color: "bg-yellow-100 text-yellow-800",
    logo: "U",
    fields: [
      { name: "accountNumber", label: "Account Number", type: "text", required: true },
      { name: "accessLicenseNumber", label: "Access License Number", type: "text", required: true },
      { name: "userId", label: "User ID", type: "text", required: true },
      { name: "password", label: "Password", type: "password", required: true }
    ]
  },
  "zoho-crm": {
    name: "Zoho CRM",
    description: "Connect Zoho CRM to manage customer relationships and inventory orders.",
    color: "bg-red-100 text-red-800",
    logo: "Z",
    fields: [
      { name: "clientId", label: "Client ID", type: "text", required: true },
      { name: "clientSecret", label: "Client Secret", type: "password", required: true },
      { name: "region", label: "Region", type: "text", required: true, 
        placeholder: "us, eu, in, au, jp" }
    ]
  }
};

const IntegrationPage = () => {
  const [match, params] = useRoute<{ id: string }>('/integrations/:id');
  const [location, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  
  // Query for user data
  const { data: user, isLoading: userLoading, error: userError } = useQuery({
    queryKey: ['/api/auth/me'],
    retry: false,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
  
  // Query existing integrations
  const { data: integrations, isLoading: integrationsLoading } = useQuery({
    queryKey: ['/api/integrations'],
    enabled: !!user,
  });
  
  // Create integration mutation
  const createIntegrationMutation = useMutation({
    mutationFn: async (integrationData: any) => {
      const res = await apiRequest('POST', '/api/integrations', integrationData);
      return await res.json();
    },
    onSuccess: () => {
      // Invalidate integrations query
      queryClient.invalidateQueries({ queryKey: ['/api/integrations'] });
      // Show success message
      toast({
        title: "Integration connected successfully",
        description: `Your ${integrationConfig?.name} account has been connected.`,
        variant: "default",
      });
      // Go to dashboard
      setLocation('/integrations');
    },
    onError: (error: any) => {
      toast({
        title: "Connection failed",
        description: error.message || "Could not connect to integration. Please check your credentials and try again.",
        variant: "destructive",
      });
      setSubmitting(false);
    },
  });
  
  // Get integration config based on ID
  const integrationId = params?.id;
  const integrationConfig = integrationId ? (integrationConfigs as any)[integrationId] : null;
  
  // Effect to check if user is authenticated
  useEffect(() => {
    if (userError) {
      setLocation('/auth');
    }
  }, [userError, setLocation]);
  
  // If no integration ID is provided, display the list of available integrations
  if (!match && !integrationsLoading && user) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <h1 className="text-3xl font-bold mb-8">Integrations</h1>
        
        {/* Connected Integrations */}
        {integrations && integrations.length > 0 && (
          <div className="mb-12">
            <h2 className="text-xl font-semibold mb-4">Connected Accounts</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {integrations.map((integration: any) => {
                const config = (integrationConfigs as any)[integration.provider] || {
                  name: integration.provider,
                  color: "bg-gray-100 text-gray-800",
                  logo: integration.provider.charAt(0).toUpperCase()
                };
                
                return (
                  <Card key={integration.id} className="overflow-hidden">
                    <CardContent className="p-6">
                      <div className="flex items-center mb-4">
                        <div className={`h-10 w-10 ${config.color} rounded-full flex items-center justify-center text-lg font-bold mr-4`}>
                          {config.logo}
                        </div>
                        <div>
                          <h3 className="font-semibold">{config.name}</h3>
                          <p className="text-sm text-gray-500">Connected</p>
                        </div>
                      </div>
                      <div className="text-sm text-gray-600 mb-4">
                        Connected on {new Date(integration.createdAt).toLocaleDateString()}
                      </div>
                      <div className="flex justify-end">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => setLocation(`/integrations/${integration.provider}`)}
                        >
                          Manage
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}
        
        {/* Available Integrations */}
        <div>
          <h2 className="text-xl font-semibold mb-4">Available Integrations</h2>
          
          {/* Featured Integrations - Amazon, Shopify, UPS, FedEx */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {['amazon', 'shopify', 'ups', 'fedex'].map((id) => {
              const config = (integrationConfigs as any)[id];
              const isConnected = integrations?.some((i: any) => i.provider === id);
              
              return (
                <Card key={id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <div className={`h-10 w-10 ${config.color} rounded-full flex items-center justify-center text-lg font-bold mr-4`}>
                        {config.logo}
                      </div>
                      <h3 className="font-semibold">{config.name}</h3>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">{config.description}</p>
                    <div className="flex justify-end">
                      <Button 
                        variant={isConnected ? "outline" : "default"}
                        onClick={() => setLocation(`/integrations/${id}`)}
                      >
                        {isConnected ? 'Manage' : 'Connect'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
          
          {/* Other Integrations */}
          <h3 className="text-lg font-medium mb-4">More Integrations</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Object.entries(integrationConfigs)
              .filter(([id]) => !['amazon', 'shopify', 'ups', 'fedex'].includes(id))
              .map(([id, config]) => {
                const isConnected = integrations?.some((i: any) => i.provider === id);
                
                return (
                  <Card key={id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-center mb-2">
                        <div className={`h-8 w-8 ${config.color} rounded-full flex items-center justify-center text-sm font-bold mr-3`}>
                          {config.logo}
                        </div>
                        <h3 className="font-medium">{config.name}</h3>
                      </div>
                      <div className="flex justify-end mt-4">
                        <Button 
                          variant={isConnected ? "outline" : "default"}
                          size="sm"
                          onClick={() => setLocation(`/integrations/${id}`)}
                        >
                          {isConnected ? 'Manage' : 'Connect'}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
          </div>
        </div>
      </div>
    );
  }
  
  // Redirect if invalid integration ID
  useEffect(() => {
    if (match && !integrationConfig) {
      setLocation('/integrations');
    }
  }, [match, integrationConfig, setLocation]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleConnect = () => {
    if (step === 1) {
      setStep(2);
    } else {
      setSubmitting(true);
      
      // Prepare integration data
      const integrationData = {
        provider: integrationId,
        providerAccountId: formData.accountId || formData.sellerId || formData.shopUrl || `${integrationId}-account`,
        accessToken: "sample-token-" + Date.now(), // In a real app, this would be an actual OAuth token
        refreshToken: "sample-refresh-" + Date.now(),
        expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 30).toISOString(), // 30 days from now
        metadata: formData
      };
      
      createIntegrationMutation.mutate(integrationData);
    }
  };
  
  if (userLoading || !integrationConfig) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-500">Loading...</p>
        </div>
      </div>
    );
  }
  
  const isFormValid = () => {
    if (step === 1) return true;
    
    if (step === 2) {
      return integrationConfig.fields.every(field => {
        return !field.required || (formData[field.name] && formData[field.name].trim() !== '');
      });
    }
    
    return false;
  };
  
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50 p-4">
      <Card className="max-w-2xl w-full bg-white shadow-lg rounded-xl">
        <CardHeader className="border-b pb-4">
          <div className="flex items-center mb-4">
            <Button 
              variant="ghost" 
              size="icon" 
              className="mr-2" 
              onClick={() => setLocation('/dashboard')}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div className="text-xl font-semibold">Connect {integrationConfig.name}</div>
          </div>
          <CardDescription>{integrationConfig.description}</CardDescription>
        </CardHeader>
        
        <CardContent className="pt-6">
          {step === 1 && (
            <div className="text-center py-8">
              <div className={`h-16 w-16 ${integrationConfig.color} rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6`}>
                {integrationConfig.logo}
              </div>
              <h2 className="text-xl font-semibold mb-2">Connect your {integrationConfig.name} account</h2>
              <p className="text-gray-500 mb-6">
                Connecting your account will allow us to sync inventory, orders, and products automatically.
              </p>
              <div className="flex flex-col space-y-4">
                <div className="p-4 bg-green-50 border border-green-100 rounded-lg text-left">
                  <h3 className="text-sm font-medium text-green-800 flex items-center">
                    <Check className="h-4 w-4 mr-2" />
                    Automatic Inventory Syncing
                  </h3>
                </div>
                <div className="p-4 bg-green-50 border border-green-100 rounded-lg text-left">
                  <h3 className="text-sm font-medium text-green-800 flex items-center">
                    <Check className="h-4 w-4 mr-2" />
                    Real-time Stock Updates
                  </h3>
                </div>
                <div className="p-4 bg-green-50 border border-green-100 rounded-lg text-left">
                  <h3 className="text-sm font-medium text-green-800 flex items-center">
                    <Check className="h-4 w-4 mr-2" />
                    Order Tracking & Management
                  </h3>
                </div>
                <div className="p-4 bg-green-50 border border-green-100 rounded-lg text-left">
                  <h3 className="text-sm font-medium text-green-800 flex items-center">
                    <Check className="h-4 w-4 mr-2" />
                    Product Information Syncing
                  </h3>
                </div>
              </div>
            </div>
          )}
          
          {step === 2 && (
            <div className="py-4">
              <h2 className="text-lg font-semibold mb-4">Enter your credentials</h2>
              <p className="text-gray-500 mb-6">
                Please provide your {integrationConfig.name} API credentials. You can find these in your account settings.
              </p>
              
              <div className="space-y-4">
                {integrationConfig.fields.map((field, index) => (
                  <div key={index}>
                    <Label htmlFor={field.name} className="mb-1 block">{field.label}</Label>
                    <Input 
                      id={field.name}
                      name={field.name}
                      type={field.type}
                      placeholder={field.placeholder}
                      value={formData[field.name] || ''}
                      onChange={handleInputChange}
                      required={field.required}
                    />
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
        
        <CardFooter className="border-t pt-4 flex justify-between">
          {step === 1 ? (
            <Button variant="outline" onClick={() => setLocation('/dashboard')}>
              Cancel
            </Button>
          ) : (
            <Button variant="outline" onClick={() => setStep(1)}>
              Back
            </Button>
          )}
          
          <Button 
            onClick={handleConnect} 
            disabled={!isFormValid() || submitting || createIntegrationMutation.isPending}
          >
            {submitting || createIntegrationMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Connecting...
              </>
            ) : step === 1 ? (
              <>
                Continue
                <ChevronRight className="ml-2 h-4 w-4" />
              </>
            ) : (
              'Connect'
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default IntegrationPage;