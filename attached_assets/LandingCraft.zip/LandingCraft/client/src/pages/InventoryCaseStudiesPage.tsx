import { Link } from "wouter";
import { ArrowRight, Quote, ChevronRight, Filter } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Case Study Data
const caseStudies = [
  {
    title: "How RetailPro Reduced Stockouts by 40% with Inventory Management",
    company: "RetailPro",
    industry: "Retail",
    companySize: "Mid-Market",
    challenge: "RetailPro, a multi-location retail chain with 12 stores, struggled with inventory visibility across locations, leading to frequent stockouts and overstock situations. Their manual inventory tracking process was error-prone and time-consuming.",
    solution: "Implemented our inventory management system with multi-location tracking, automated reorder points, and real-time inventory visibility. Integrated with their POS system and e-commerce platform.",
    results: [
      "Reduced stockouts by 40% within 3 months",
      "Decreased excess inventory by 25%, freeing up capital",
      "Saved 30+ hours per week on manual inventory management",
      "Improved customer satisfaction with 98% in-stock rate"
    ],
    quote: "The inventory system transformed our operations. We now have real-time visibility across all locations, and the automated reordering has virtually eliminated our stockout issues.",
    personName: "Sarah Johnson",
    personTitle: "Operations Director, RetailPro",
    featured: true
  },
  {
    title: "E-Commerce Success: TechGadgets Manages 300% Growth with Scalable Inventory Solution",
    company: "TechGadgets",
    industry: "E-commerce",
    companySize: "Small Business",
    challenge: "TechGadgets, an online electronics retailer, experienced 300% growth in 6 months but struggled to scale their inventory operations. They faced shipping errors, overselling items, and customer service issues.",
    solution: "Deployed our inventory system with multi-channel synchronization for their Shopify, Amazon, and eBay stores. Implemented batch tracking and automated fulfillment processes.",
    results: [
      "Successfully managed 300% order volume increase without adding staff",
      "Reduced order fulfillment errors by 95%",
      "Cut average shipping time from 3 days to 1 day",
      "Improved inventory accuracy to 99.8%"
    ],
    quote: "As our business exploded in growth, the inventory system scaled perfectly with us. The multi-channel sync saved us countless hours and prevented overselling across platforms.",
    personName: "Michael Chen",
    personTitle: "Founder, TechGadgets",
    featured: true
  },
  {
    title: "Manufacturing Efficiency: GlobalFab Streamlines Production with Inventory Tracking",
    company: "GlobalFab",
    industry: "Manufacturing",
    companySize: "Enterprise",
    challenge: "GlobalFab, a manufacturing company with facilities in three countries, struggled with raw material management and production planning due to disconnected inventory systems and manual tracking processes.",
    solution: "Implemented our inventory management system with batch/lot tracking, multi-warehouse management, and production planning integration. Connected with their ERP system for seamless data flow.",
    results: [
      "Reduced production delays by 35% through improved material availability",
      "Lowered raw material inventory by 20% while maintaining production levels",
      "Improved traceability with lot tracking throughout production",
      "Decreased end-of-month inventory reconciliation time by 80%"
    ],
    quote: "The system gives us unprecedented visibility into our raw materials across all facilities. Our production planning is now data-driven and far more efficient.",
    personName: "Robert Adams",
    personTitle: "Supply Chain Director, GlobalFab",
    featured: false
  },
  {
    title: "Wholesale Distribution: MaxSupply Enhances Customer Service with Real-Time Inventory",
    company: "MaxSupply",
    industry: "Wholesale",
    companySize: "Mid-Market",
    challenge: "MaxSupply, a wholesale distributor of industrial supplies, struggled with inaccurate inventory counts, leading to backorders, customer dissatisfaction, and lost sales opportunities.",
    solution: "Implemented our inventory system with barcode scanning, real-time inventory updates, and integration with their CRM for sales team visibility.",
    results: [
      "Increased inventory accuracy from 86% to 99%",
      "Reduced backorders by 65%",
      "Empowered sales team with real-time inventory visibility",
      "Improved customer retention rate by 18%"
    ],
    quote: "Our sales team now has complete confidence in our inventory data. They can make promises to customers that we can actually keep, which has dramatically improved our customer relationships.",
    personName: "Jennifer Miller",
    personTitle: "Sales Director, MaxSupply",
    featured: false
  },
  {
    title: "Healthcare Supply Management: MedPro Improves Patient Care with Efficient Inventory",
    company: "MedPro",
    industry: "Healthcare",
    companySize: "Enterprise",
    challenge: "MedPro, a healthcare provider with multiple facilities, faced challenges managing medical supplies across locations, leading to emergency orders, expired products, and inefficient spending.",
    solution: "Implemented our inventory system with expiration date tracking, mobile scanning, and multi-location management. Integrated with their procurement system for streamlined purchasing.",
    results: [
      "Reduced expired product waste by 85%",
      "Decreased emergency orders by 92%",
      "Lowered overall supply spend by 12%",
      "Improved critical supply availability to 99.9%"
    ],
    quote: "The inventory system helps us ensure that the right supplies are always available for patient care, while significantly reducing waste and unnecessary spending.",
    personName: "Dr. Amanda Williams",
    personTitle: "Director of Operations, MedPro",
    featured: false
  },
  {
    title: "Food Service Optimization: FreshServe Manages Perishable Inventory with Precision",
    company: "FreshServe",
    industry: "Food & Beverage",
    companySize: "Small Business",
    challenge: "FreshServe, a food service provider, struggled with managing perishable inventory, leading to significant food waste, inconsistent ordering, and difficulty tracking food costs.",
    solution: "Implemented our inventory system with FIFO tracking, shelf-life management, and supplier integration. Added mobile scanning for quick stock counts and receiving.",
    results: [
      "Reduced food waste by 43% in the first quarter",
      "Improved inventory turnover by 30%",
      "Decreased food cost percentage from 36% to 28%",
      "Streamlined ordering process, saving 15 hours per week"
    ],
    quote: "Our perishable inventory management has completely transformed. We've cut our waste nearly in half while ensuring we always have the fresh ingredients we need.",
    personName: "Carlos Rodriguez",
    personTitle: "Owner, FreshServe",
    featured: false
  }
];

const InventoryCaseStudiesPage = () => {
  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-primary-700 text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl font-bold mb-4">Customer Success Stories</h1>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              See how businesses across industries have transformed their operations with our inventory management solution
            </p>
          </div>
        </section>

        {/* Featured Case Studies */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-12 text-center">Featured Success Stories</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {caseStudies
                .filter(study => study.featured)
                .map((study, index) => (
                  <div 
                    key={index} 
                    className="bg-white rounded-lg shadow-lg overflow-hidden flex flex-col h-full border border-gray-200"
                  >
                    <div className="bg-primary-50 p-4">
                      <div className="flex justify-between items-start mb-4">
                        <Badge className="bg-primary-100 text-primary hover:bg-primary-100">{study.industry}</Badge>
                        <Badge variant="outline">{study.companySize}</Badge>
                      </div>
                      <h3 className="text-2xl font-bold mb-2 text-gray-900">{study.title}</h3>
                      <p className="text-primary font-semibold">{study.company}</p>
                    </div>
                    
                    <div className="p-6 flex-1">
                      <div className="mb-6">
                        <h4 className="font-semibold text-lg mb-2">Challenge</h4>
                        <p className="text-gray-700">{study.challenge}</p>
                      </div>
                      
                      <div className="mb-6">
                        <h4 className="font-semibold text-lg mb-2">Solution</h4>
                        <p className="text-gray-700">{study.solution}</p>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-lg mb-2">Results</h4>
                        <ul className="list-disc pl-5 space-y-1 text-gray-700">
                          {study.results.map((result, i) => (
                            <li key={i}>{result}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                    
                    <div className="p-6 bg-gray-50 border-t border-gray-200">
                      <div className="flex items-start">
                        <Quote className="h-10 w-10 text-primary-300 mr-4 flex-shrink-0" />
                        <div>
                          <p className="italic text-gray-700 mb-4">{study.quote}</p>
                          <div>
                            <p className="font-semibold">{study.personName}</p>
                            <p className="text-sm text-gray-600">{study.personTitle}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-6 bg-white border-t border-gray-200">
                      <Button variant="outline" className="w-full" asChild>
                        <Link href={`/inventory/case-studies/${study.company.toLowerCase().replace(/\s+/g, '-')}`}>
                          Read Full Case Study <ChevronRight className="ml-2 h-4 w-4" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </section>

        {/* Case Study Filters */}
        <section className="py-8 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between items-center mb-8">
              <h2 className="text-2xl font-bold mb-4 md:mb-0">All Case Studies</h2>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex items-center">
                  <Filter className="h-5 w-5 text-gray-500 mr-2" />
                  <span className="text-sm text-gray-500 mr-3">Filter by:</span>
                </div>
                
                <Select>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Industry" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Industries</SelectItem>
                    <SelectItem value="retail">Retail</SelectItem>
                    <SelectItem value="ecommerce">E-commerce</SelectItem>
                    <SelectItem value="manufacturing">Manufacturing</SelectItem>
                    <SelectItem value="wholesale">Wholesale</SelectItem>
                    <SelectItem value="healthcare">Healthcare</SelectItem>
                    <SelectItem value="food">Food & Beverage</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Company Size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Sizes</SelectItem>
                    <SelectItem value="small">Small Business</SelectItem>
                    <SelectItem value="mid">Mid-Market</SelectItem>
                    <SelectItem value="enterprise">Enterprise</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </section>

        {/* All Case Studies */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {caseStudies.map((study, index) => (
                <Card key={index} className="flex flex-col h-full">
                  <CardContent className="p-6 flex-1">
                    <div className="flex justify-between items-start mb-4">
                      <Badge className="bg-primary-100 text-primary hover:bg-primary-100">{study.industry}</Badge>
                      <Badge variant="outline">{study.companySize}</Badge>
                    </div>
                    
                    <h3 className="text-xl font-bold mb-3">{study.title}</h3>
                    <p className="text-primary font-semibold mb-4">{study.company}</p>
                    
                    <div className="mb-4">
                      <h4 className="font-semibold mb-1">Challenge</h4>
                      <p className="text-gray-700 text-sm line-clamp-3">{study.challenge}</p>
                    </div>
                    
                    <div className="mb-4">
                      <h4 className="font-semibold mb-1">Results</h4>
                      <ul className="text-sm text-gray-700 space-y-1">
                        <li className="flex items-start">
                          <span className="text-primary mr-2">•</span>
                          <span>{study.results[0]}</span>
                        </li>
                        {study.results.length > 1 && (
                          <li className="text-gray-500 italic">+ {study.results.length - 1} more results</li>
                        )}
                      </ul>
                    </div>
                    
                    <Button variant="outline" className="w-full mt-4" asChild>
                      <Link href={`/inventory/case-studies/${study.company.toLowerCase().replace(/\s+/g, '-')}`}>
                        Read Case Study <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Results Overview */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Proven Results Across Industries</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Our customers consistently report significant improvements in their inventory operations
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-5xl mx-auto">
              <div className="bg-white rounded-lg shadow-md p-6 text-center">
                <div className="text-4xl font-bold text-primary mb-2">40%</div>
                <p className="text-gray-700">Average reduction in stockouts</p>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6 text-center">
                <div className="text-4xl font-bold text-primary mb-2">25%</div>
                <p className="text-gray-700">Average decrease in excess inventory</p>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6 text-center">
                <div className="text-4xl font-bold text-primary mb-2">20+</div>
                <p className="text-gray-700">Hours saved weekly on inventory tasks</p>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6 text-center">
                <div className="text-4xl font-bold text-primary mb-2">99%</div>
                <p className="text-gray-700">Average inventory accuracy achieved</p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-primary-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to achieve similar results?</h2>
            <p className="text-xl text-primary-100 max-w-3xl mx-auto mb-8">
              Join thousands of businesses that have transformed their inventory management.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button variant="secondary" size="lg" asChild>
                <Link href="/register">Start Free Trial</Link>
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="bg-transparent border border-white text-white hover:bg-white/10"
                asChild
              >
                <Link href="/contact">Schedule a Demo</Link>
              </Button>
            </div>
            <p className="mt-4 text-sm text-primary-200">No credit card required. 14-day free trial.</p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default InventoryCaseStudiesPage;