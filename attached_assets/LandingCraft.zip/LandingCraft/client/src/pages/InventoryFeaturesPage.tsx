import { Link } from "wouter";
import { ArrowRight, Check, BarChart, ShoppingCart, Truck, Clock, Database, Globe, Shield } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const InventoryFeaturesPage = () => {
  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-primary-700 text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl font-bold mb-4">Powerful Inventory Management Features</h1>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Discover the comprehensive toolset designed to streamline your inventory operations
            </p>
          </div>
        </section>

        {/* Feature Navigation */}
        <section className="py-8 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap justify-center gap-4">
              <Button variant="outline" asChild>
                <a href="#order-management">Order Management</a>
              </Button>
              <Button variant="outline" asChild>
                <a href="#inventory-control">Inventory Control</a>
              </Button>
              <Button variant="outline" asChild>
                <a href="#shipping">Shipping</a>
              </Button>
              <Button variant="outline" asChild>
                <a href="#reporting">Reporting</a>
              </Button>
              <Button variant="outline" asChild>
                <a href="#integrations">Integrations</a>
              </Button>
              <Button variant="outline" asChild>
                <a href="#automation">Automation</a>
              </Button>
            </div>
          </div>
        </section>

        {/* Order Management Section */}
        <section id="order-management" className="py-16">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center mb-12">
              <div className="md:w-1/2 mb-8 md:mb-0 md:pr-12">
                <h2 className="text-3xl font-bold mb-4">Order Management</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Centralize and streamline your order processing from multiple sales channels for maximum efficiency.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Multi-Channel Order Synchronization</h3>
                      <p className="text-gray-600">
                        Automatically import orders from all your sales channels into a single dashboard.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Purchase Order Management</h3>
                      <p className="text-gray-600">
                        Create, track, and manage purchase orders with your suppliers for streamlined procurement.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Sales Order Processing</h3>
                      <p className="text-gray-600">
                        Convert quotes to sales orders, track fulfillment status, and manage customer communications.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Dropshipping Management</h3>
                      <p className="text-gray-600">
                        Seamlessly manage and automate dropshipping workflows between vendors and customers.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="md:w-1/2">
                <div className="bg-gray-100 rounded-lg p-6 flex items-center justify-center">
                  <div className="w-full h-72 bg-white rounded-lg shadow-inner flex items-center justify-center">
                    <ShoppingCart className="h-20 w-20 text-gray-300" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Inventory Control Section */}
        <section id="inventory-control" className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row-reverse items-center mb-12">
              <div className="md:w-1/2 mb-8 md:mb-0 md:pl-12">
                <h2 className="text-3xl font-bold mb-4">Inventory Control</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Take complete control of your inventory with real-time tracking and powerful management tools.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Real-Time Stock Tracking</h3>
                      <p className="text-gray-600">
                        Monitor inventory levels across all locations with real-time updates and alerts.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Batch and Serial Number Tracking</h3>
                      <p className="text-gray-600">
                        Track items by batch, lot, or serial number for improved quality control and traceability.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Automated Reorder Points</h3>
                      <p className="text-gray-600">
                        Set automatic reorder triggers based on minimum stock levels to prevent stockouts.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Multi-Warehouse Management</h3>
                      <p className="text-gray-600">
                        Manage inventory across multiple warehouses and locations with transfer tracking.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="md:w-1/2">
                <div className="bg-gray-100 rounded-lg p-6 flex items-center justify-center">
                  <div className="w-full h-72 bg-white rounded-lg shadow-inner flex items-center justify-center">
                    <Database className="h-20 w-20 text-gray-300" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Shipping Section */}
        <section id="shipping" className="py-16">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center mb-12">
              <div className="md:w-1/2 mb-8 md:mb-0 md:pr-12">
                <h2 className="text-3xl font-bold mb-4">Shipping</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Streamline your shipping process with integrated carrier options and automated documentation.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Integrated Shipping Label Generation</h3>
                      <p className="text-gray-600">
                        Create and print shipping labels directly from the platform with major carriers.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Multiple Carrier Support</h3>
                      <p className="text-gray-600">
                        Integrate with FedEx, UPS, USPS, DHL, and other major shipping providers.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Automated Packing Slips</h3>
                      <p className="text-gray-600">
                        Generate professional packing slips, invoices, and shipping documentation.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Shipping Rate Comparison</h3>
                      <p className="text-gray-600">
                        Compare shipping rates across carriers to find the most cost-effective options.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="md:w-1/2">
                <div className="bg-gray-100 rounded-lg p-6 flex items-center justify-center">
                  <div className="w-full h-72 bg-white rounded-lg shadow-inner flex items-center justify-center">
                    <Truck className="h-20 w-20 text-gray-300" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Reporting Section */}
        <section id="reporting" className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row-reverse items-center mb-12">
              <div className="md:w-1/2 mb-8 md:mb-0 md:pl-12">
                <h2 className="text-3xl font-bold mb-4">Reporting</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Make data-driven decisions with comprehensive analytics and customizable reports.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Real-Time Inventory Analytics</h3>
                      <p className="text-gray-600">
                        Get up-to-the-minute data on stock levels, sales velocity, and inventory performance.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Inventory Valuation Reports</h3>
                      <p className="text-gray-600">
                        Generate accurate valuation reports using FIFO, LIFO, or average cost methods.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Profit and Loss Reporting</h3>
                      <p className="text-gray-600">
                        Track product profitability with detailed margin analysis and cost tracking.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Custom Report Builder</h3>
                      <p className="text-gray-600">
                        Create tailored reports with drag-and-drop tools to focus on your key metrics.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="md:w-1/2">
                <div className="bg-gray-100 rounded-lg p-6 flex items-center justify-center">
                  <div className="w-full h-72 bg-white rounded-lg shadow-inner flex items-center justify-center">
                    <BarChart className="h-20 w-20 text-gray-300" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Integrations Section */}
        <section id="integrations" className="py-16">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center mb-12">
              <div className="md:w-1/2 mb-8 md:mb-0 md:pr-12">
                <h2 className="text-3xl font-bold mb-4">Integrations</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Connect your inventory system with your favorite e-commerce, accounting, and shipping platforms.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">E-commerce Platforms</h3>
                      <p className="text-gray-600">
                        Integrate with Shopify, Amazon, eBay, WooCommerce, and more to sync orders and inventory.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Accounting Software</h3>
                      <p className="text-gray-600">
                        Connect with QuickBooks, Xero, Zoho Books, and other accounting tools for seamless financial tracking.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Shipping Carriers</h3>
                      <p className="text-gray-600">
                        Integrate with FedEx, UPS, USPS, DHL, and other carriers for shipping rate calculation and label printing.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">CRM Systems</h3>
                      <p className="text-gray-600">
                        Connect with Zoho CRM, Salesforce, and other CRM platforms for customer and order management.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="md:w-1/2">
                <div className="bg-gray-100 rounded-lg p-6 flex items-center justify-center">
                  <div className="w-full h-72 bg-white rounded-lg shadow-inner flex items-center justify-center">
                    <Globe className="h-20 w-20 text-gray-300" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Automation Section */}
        <section id="automation" className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row-reverse items-center mb-12">
              <div className="md:w-1/2 mb-8 md:mb-0 md:pl-12">
                <h2 className="text-3xl font-bold mb-4">Automation</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Save time and reduce errors with powerful automation tools that streamline inventory workflows.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Workflow Rules</h3>
                      <p className="text-gray-600">
                        Create custom rules to automate order processing, inventory updates, and notifications.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Reorder Alerts</h3>
                      <p className="text-gray-600">
                        Receive automatic notifications when inventory reaches reorder points to prevent stockouts.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Barcode Scanning</h3>
                      <p className="text-gray-600">
                        Use barcode scanners for quick and accurate inventory updates, picking, and packing.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Scheduled Reports</h3>
                      <p className="text-gray-600">
                        Set up automated report generation and distribution to keep your team informed.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="md:w-1/2">
                <div className="bg-gray-100 rounded-lg p-6 flex items-center justify-center">
                  <div className="w-full h-72 bg-white rounded-lg shadow-inner flex items-center justify-center">
                    <Clock className="h-20 w-20 text-gray-300" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Security Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Secure and Reliable</h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Your inventory data is protected with enterprise-grade security and reliability
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <Card className="text-center">
                <CardContent className="pt-6">
                  <div className="h-12 w-12 bg-primary-100 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <Shield className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Data Encryption</h3>
                  <p className="text-gray-600">
                    All your data is encrypted in transit and at rest using industry-standard protocols.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="text-center">
                <CardContent className="pt-6">
                  <div className="h-12 w-12 bg-primary-100 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <Shield className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Regular Backups</h3>
                  <p className="text-gray-600">
                    Automated backups ensure your inventory data is always protected against loss.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="text-center">
                <CardContent className="pt-6">
                  <div className="h-12 w-12 bg-primary-100 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <Shield className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Role-Based Access</h3>
                  <p className="text-gray-600">
                    Control who can view and modify inventory data with granular permission settings.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-primary-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to streamline your inventory management?</h2>
            <p className="text-xl text-primary-100 max-w-3xl mx-auto mb-8">
              Join thousands of businesses that have transformed their operations with our powerful inventory solution.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button variant="secondary" size="lg" asChild>
                <Link href="/register">Start Free Trial</Link>
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="bg-transparent border border-white text-white hover:bg-white/10"
                asChild
              >
                <Link href="/inventory/pricing">See Pricing Plans</Link>
              </Button>
            </div>
            <p className="mt-4 text-sm text-primary-200">No credit card required. 14-day free trial.</p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default InventoryFeaturesPage;