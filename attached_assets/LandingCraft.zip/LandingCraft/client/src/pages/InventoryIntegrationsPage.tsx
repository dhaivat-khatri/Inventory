import { Link } from "wouter";
import { ArrowRight, Check, ArrowUpRight, SearchIcon } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

// Integration data
const integrations = [
  // E-commerce
  {
    name: "Shopify",
    category: "ecommerce",
    description: "Sync inventory, orders, and products with your Shopify store.",
    features: ["Auto-sync orders", "Real-time inventory updates", "Product management", "Customer data sync"],
    popular: true
  },
  {
    name: "Amazon",
    category: "ecommerce",
    description: "Manage your Amazon marketplace inventory and orders.",
    features: ["FBA integration", "Order fulfillment", "Inventory tracking", "Multi-channel synchronization"],
    popular: true
  },
  {
    name: "WooCommerce",
    category: "ecommerce",
    description: "Connect your WooCommerce store for seamless inventory management.",
    features: ["WordPress integration", "Product sync", "Order management", "Customer data"],
    popular: false
  },
  {
    name: "eBay",
    category: "ecommerce",
    description: "Integrate your eBay listings and manage inventory across channels.",
    features: ["Multi-listing support", "Automated inventory updates", "Order tracking", "Shipping integration"],
    popular: false
  },
  {
    name: "Magento",
    category: "ecommerce",
    description: "Connect your Magento store for comprehensive inventory control.",
    features: ["Product catalog sync", "Order management", "Customer data integration", "Multi-store support"],
    popular: false
  },
  
  // Accounting
  {
    name: "QuickBooks",
    category: "accounting",
    description: "Streamline your accounting with QuickBooks integration.",
    features: ["Invoice sync", "Financial reporting", "Tax calculation", "Expense tracking"],
    popular: true
  },
  {
    name: "Xero",
    category: "accounting",
    description: "Connect your Xero account for seamless financial management.",
    features: ["Automated reconciliation", "Invoice generation", "Financial reporting", "Tax compliance"],
    popular: false
  },
  {
    name: "Zoho Books",
    category: "accounting",
    description: "Integrate with Zoho Books for comprehensive financial tracking.",
    features: ["Deep Zoho ecosystem integration", "Automated invoicing", "Expense tracking", "Financial reports"],
    popular: true
  },
  {
    name: "Sage",
    category: "accounting",
    description: "Connect with Sage for enterprise-grade financial management.",
    features: ["Advanced accounting features", "Multi-entity support", "Compliance tools", "Financial planning"],
    popular: false
  },
  
  // Shipping
  {
    name: "FedEx",
    category: "shipping",
    description: "Print FedEx labels and manage shipments directly.",
    features: ["Rate comparison", "Label printing", "Tracking integration", "International shipping"],
    popular: true
  },
  {
    name: "UPS",
    category: "shipping",
    description: "Integrate UPS shipping for streamlined order fulfillment.",
    features: ["Automated label generation", "Rate shopping", "Tracking updates", "Return management"],
    popular: false
  },
  {
    name: "USPS",
    category: "shipping",
    description: "Connect with USPS for cost-effective shipping options.",
    features: ["Discounted rates", "Domestic priority shipping", "International options", "Tracking integration"],
    popular: false
  },
  {
    name: "DHL",
    category: "shipping",
    description: "Manage international shipments with DHL integration.",
    features: ["Global shipping options", "Customs documentation", "Rate calculation", "Tracking services"],
    popular: false
  },
  {
    name: "ShipStation",
    category: "shipping",
    description: "Centralize your shipping processes with ShipStation.",
    features: ["Multi-carrier support", "Order management", "Automation rules", "Returns management"],
    popular: true
  },
  
  // CRM
  {
    name: "Zoho CRM",
    category: "crm",
    description: "Connect your customer data with Zoho CRM integration.",
    features: ["Contact synchronization", "Order history", "Customer communication", "Pipeline management"],
    popular: true
  },
  {
    name: "Salesforce",
    category: "crm",
    description: "Integrate with Salesforce for enterprise CRM capabilities.",
    features: ["360° customer view", "Opportunity tracking", "Sales automation", "Customer insights"],
    popular: false
  },
  {
    name: "HubSpot",
    category: "crm",
    description: "Connect with HubSpot for marketing and sales alignment.",
    features: ["Contact management", "Marketing automation", "Sales pipeline", "Customer service tools"],
    popular: false
  },
  {
    name: "Pipedrive",
    category: "crm",
    description: "Streamline your sales process with Pipedrive integration.",
    features: ["Deal tracking", "Sales pipeline", "Activity scheduling", "Customer data management"],
    popular: false
  }
];

const InventoryIntegrationsPage = () => {
  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-primary-700 text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl font-bold mb-4">Connect Your Business Tools</h1>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Integrate seamlessly with your favorite e-commerce, accounting, shipping, and CRM platforms
            </p>
            <div className="max-w-lg mx-auto relative">
              <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input 
                className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/60 focus-visible:ring-white/30"
                placeholder="Search integrations..."
              />
            </div>
          </div>
        </section>

        {/* Integration Categories */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <Tabs defaultValue="all" className="w-full">
              <div className="flex justify-center mb-12">
                <TabsList className="bg-gray-100">
                  <TabsTrigger value="all">All Integrations</TabsTrigger>
                  <TabsTrigger value="ecommerce">E-commerce</TabsTrigger>
                  <TabsTrigger value="accounting">Accounting</TabsTrigger>
                  <TabsTrigger value="shipping">Shipping</TabsTrigger>
                  <TabsTrigger value="crm">CRM</TabsTrigger>
                </TabsList>
              </div>
              
              <TabsContent value="all">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {integrations.map((integration, index) => (
                    <Card key={index} className="relative overflow-hidden flex flex-col h-full">
                      {integration.popular && (
                        <span className="absolute top-0 right-0 bg-primary text-white text-xs px-3 py-1 rounded-bl-lg">
                          Popular
                        </span>
                      )}
                      <CardHeader>
                        <div className="flex items-center justify-between mb-2">
                          <div className="h-12 w-12 bg-primary-100 rounded-full flex items-center justify-center">
                            <span className="text-primary text-xl font-bold">{integration.name.charAt(0)}</span>
                          </div>
                          <Badge variant="outline" className="capitalize">
                            {integration.category}
                          </Badge>
                        </div>
                        <CardTitle>{integration.name}</CardTitle>
                        <CardDescription>{integration.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="flex-1">
                        <h4 className="font-medium mb-2">Key Features</h4>
                        <ul className="space-y-1">
                          {integration.features.map((feature, i) => (
                            <li key={i} className="flex items-start">
                              <Check className="h-4 w-4 text-primary mr-2 flex-shrink-0" />
                              <span className="text-sm">{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                      <CardFooter>
                        <Button variant="outline" className="w-full" asChild>
                          <Link href={`/inventory/integrations/${integration.name.toLowerCase()}`} className="flex items-center justify-center">
                            Learn More <ArrowUpRight className="ml-2 h-4 w-4" />
                          </Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="ecommerce">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {integrations
                    .filter(integration => integration.category === "ecommerce")
                    .map((integration, index) => (
                      <Card key={index} className="relative overflow-hidden flex flex-col h-full">
                        {integration.popular && (
                          <span className="absolute top-0 right-0 bg-primary text-white text-xs px-3 py-1 rounded-bl-lg">
                            Popular
                          </span>
                        )}
                        <CardHeader>
                          <div className="flex items-center justify-between mb-2">
                            <div className="h-12 w-12 bg-primary-100 rounded-full flex items-center justify-center">
                              <span className="text-primary text-xl font-bold">{integration.name.charAt(0)}</span>
                            </div>
                            <Badge variant="outline" className="capitalize">
                              {integration.category}
                            </Badge>
                          </div>
                          <CardTitle>{integration.name}</CardTitle>
                          <CardDescription>{integration.description}</CardDescription>
                        </CardHeader>
                        <CardContent className="flex-1">
                          <h4 className="font-medium mb-2">Key Features</h4>
                          <ul className="space-y-1">
                            {integration.features.map((feature, i) => (
                              <li key={i} className="flex items-start">
                                <Check className="h-4 w-4 text-primary mr-2 flex-shrink-0" />
                                <span className="text-sm">{feature}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                        <CardFooter>
                          <Button variant="outline" className="w-full" asChild>
                            <Link href={`/inventory/integrations/${integration.name.toLowerCase()}`} className="flex items-center justify-center">
                              Learn More <ArrowUpRight className="ml-2 h-4 w-4" />
                            </Link>
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                </div>
              </TabsContent>
              
              <TabsContent value="accounting">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {integrations
                    .filter(integration => integration.category === "accounting")
                    .map((integration, index) => (
                      <Card key={index} className="relative overflow-hidden flex flex-col h-full">
                        {integration.popular && (
                          <span className="absolute top-0 right-0 bg-primary text-white text-xs px-3 py-1 rounded-bl-lg">
                            Popular
                          </span>
                        )}
                        <CardHeader>
                          <div className="flex items-center justify-between mb-2">
                            <div className="h-12 w-12 bg-primary-100 rounded-full flex items-center justify-center">
                              <span className="text-primary text-xl font-bold">{integration.name.charAt(0)}</span>
                            </div>
                            <Badge variant="outline" className="capitalize">
                              {integration.category}
                            </Badge>
                          </div>
                          <CardTitle>{integration.name}</CardTitle>
                          <CardDescription>{integration.description}</CardDescription>
                        </CardHeader>
                        <CardContent className="flex-1">
                          <h4 className="font-medium mb-2">Key Features</h4>
                          <ul className="space-y-1">
                            {integration.features.map((feature, i) => (
                              <li key={i} className="flex items-start">
                                <Check className="h-4 w-4 text-primary mr-2 flex-shrink-0" />
                                <span className="text-sm">{feature}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                        <CardFooter>
                          <Button variant="outline" className="w-full" asChild>
                            <Link href={`/inventory/integrations/${integration.name.toLowerCase()}`} className="flex items-center justify-center">
                              Learn More <ArrowUpRight className="ml-2 h-4 w-4" />
                            </Link>
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                </div>
              </TabsContent>
              
              <TabsContent value="shipping">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {integrations
                    .filter(integration => integration.category === "shipping")
                    .map((integration, index) => (
                      <Card key={index} className="relative overflow-hidden flex flex-col h-full">
                        {integration.popular && (
                          <span className="absolute top-0 right-0 bg-primary text-white text-xs px-3 py-1 rounded-bl-lg">
                            Popular
                          </span>
                        )}
                        <CardHeader>
                          <div className="flex items-center justify-between mb-2">
                            <div className="h-12 w-12 bg-primary-100 rounded-full flex items-center justify-center">
                              <span className="text-primary text-xl font-bold">{integration.name.charAt(0)}</span>
                            </div>
                            <Badge variant="outline" className="capitalize">
                              {integration.category}
                            </Badge>
                          </div>
                          <CardTitle>{integration.name}</CardTitle>
                          <CardDescription>{integration.description}</CardDescription>
                        </CardHeader>
                        <CardContent className="flex-1">
                          <h4 className="font-medium mb-2">Key Features</h4>
                          <ul className="space-y-1">
                            {integration.features.map((feature, i) => (
                              <li key={i} className="flex items-start">
                                <Check className="h-4 w-4 text-primary mr-2 flex-shrink-0" />
                                <span className="text-sm">{feature}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                        <CardFooter>
                          <Button variant="outline" className="w-full" asChild>
                            <Link href={`/inventory/integrations/${integration.name.toLowerCase()}`} className="flex items-center justify-center">
                              Learn More <ArrowUpRight className="ml-2 h-4 w-4" />
                            </Link>
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                </div>
              </TabsContent>
              
              <TabsContent value="crm">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {integrations
                    .filter(integration => integration.category === "crm")
                    .map((integration, index) => (
                      <Card key={index} className="relative overflow-hidden flex flex-col h-full">
                        {integration.popular && (
                          <span className="absolute top-0 right-0 bg-primary text-white text-xs px-3 py-1 rounded-bl-lg">
                            Popular
                          </span>
                        )}
                        <CardHeader>
                          <div className="flex items-center justify-between mb-2">
                            <div className="h-12 w-12 bg-primary-100 rounded-full flex items-center justify-center">
                              <span className="text-primary text-xl font-bold">{integration.name.charAt(0)}</span>
                            </div>
                            <Badge variant="outline" className="capitalize">
                              {integration.category}
                            </Badge>
                          </div>
                          <CardTitle>{integration.name}</CardTitle>
                          <CardDescription>{integration.description}</CardDescription>
                        </CardHeader>
                        <CardContent className="flex-1">
                          <h4 className="font-medium mb-2">Key Features</h4>
                          <ul className="space-y-1">
                            {integration.features.map((feature, i) => (
                              <li key={i} className="flex items-start">
                                <Check className="h-4 w-4 text-primary mr-2 flex-shrink-0" />
                                <span className="text-sm">{feature}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                        <CardFooter>
                          <Button variant="outline" className="w-full" asChild>
                            <Link href={`/inventory/integrations/${integration.name.toLowerCase()}`} className="flex items-center justify-center">
                              Learn More <ArrowUpRight className="ml-2 h-4 w-4" />
                            </Link>
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* Integration Process */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">How Integration Works</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Connect your tools in just a few simple steps
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="bg-white rounded-lg shadow-md p-6 text-center relative">
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-primary text-white h-8 w-8 rounded-full flex items-center justify-center text-lg font-bold">
                  1
                </div>
                <h3 className="text-xl font-semibold mb-3 mt-4">Choose Integration</h3>
                <p className="text-gray-600">
                  Select from our wide range of available integrations to connect with your existing tools.
                </p>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6 text-center relative">
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-primary text-white h-8 w-8 rounded-full flex items-center justify-center text-lg font-bold">
                  2
                </div>
                <h3 className="text-xl font-semibold mb-3 mt-4">Authorize Connection</h3>
                <p className="text-gray-600">
                  Log in to your account and authorize the secure connection between systems.
                </p>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6 text-center relative">
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-primary text-white h-8 w-8 rounded-full flex items-center justify-center text-lg font-bold">
                  3
                </div>
                <h3 className="text-xl font-semibold mb-3 mt-4">Configure Settings</h3>
                <p className="text-gray-600">
                  Customize synchronization settings and start enjoying automated data flow between systems.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* API Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 mb-8 md:mb-0 md:pr-12">
                <h2 className="text-3xl font-bold mb-4">Custom Integration with Our API</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Need a custom integration solution? Our robust API allows developers to build tailored connections between our inventory system and your unique business tools.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">RESTful API</h3>
                      <p className="text-gray-600">
                        Industry-standard RESTful API with comprehensive documentation.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Webhook Support</h3>
                      <p className="text-gray-600">
                        Real-time event notifications with configurable webhooks.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="flex-shrink-0 mr-3">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Developer Resources</h3>
                      <p className="text-gray-600">
                        Comprehensive guides, SDKs, and sample code to accelerate development.
                      </p>
                    </div>
                  </li>
                </ul>
                <Button className="mt-6" asChild>
                  <Link href="/inventory/api-docs">View API Documentation</Link>
                </Button>
              </div>
              <div className="md:w-1/2 bg-gray-900 rounded-lg p-6">
                <pre className="text-green-400 text-sm overflow-x-auto">
                  <code>
{`// Example API Request for Inventory Items
fetch('https://api.bizsuite.com/v1/inventory/items', {
  method: 'GET',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  }
})
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.error('Error:', error));`}
                  </code>
                </pre>
              </div>
            </div>
          </div>
        </section>

        {/* Need Help Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Need Help with Integration?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Our team is ready to assist you with custom integration needs
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button asChild>
                <Link href="/contact">Contact Support</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/inventory/integrations/faq">View Integration FAQ</Link>
              </Button>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-primary-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to unify your business systems?</h2>
            <p className="text-xl text-primary-100 max-w-3xl mx-auto mb-8">
              Start connecting your tools today and experience seamless data flow across your business.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button variant="secondary" size="lg" asChild>
                <Link href="/register">Start Free Trial</Link>
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="bg-transparent border border-white text-white hover:bg-white/10"
                asChild
              >
                <Link href="/contact">Schedule a Demo</Link>
              </Button>
            </div>
            <p className="mt-4 text-sm text-primary-200">No credit card required. 14-day free trial.</p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default InventoryIntegrationsPage;