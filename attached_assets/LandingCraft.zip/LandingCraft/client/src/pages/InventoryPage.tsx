import { Link } from "wouter";
import { ArrowRight, Check, ShoppingCart, BarChart2, Truck, Clock, BarChart, ExternalLink } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const InventoryPage = () => {
  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-primary-700 text-white py-20">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 mb-8 md:mb-0">
                <h1 className="text-4xl lg:text-5xl font-bold mb-4">Streamline Your Inventory Management</h1>
                <p className="text-xl mb-8 text-primary-100">
                  Take control of your inventory with powerful tools for multi-channel integration, order management, automation, and comprehensive reporting.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button variant="secondary" size="lg" asChild>
                    <Link href="/register">Start Free Trial</Link>
                  </Button>
                  <Button variant="outline" size="lg" className="bg-transparent border border-white text-white hover:bg-white/10" asChild>
                    <Link href="/contact">Schedule a Demo</Link>
                  </Button>
                </div>
                <p className="mt-4 text-sm text-primary-100">No credit card required. 14-day free trial.</p>
              </div>
              <div className="md:w-1/2">
                <div className="bg-white/10 rounded-lg p-8">
                  <img 
                    src="/inventory-dashboard.svg" 
                    alt="Inventory Dashboard" 
                    className="w-full h-auto rounded-lg shadow-lg"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 600 400'%3E%3Crect width='600' height='400' fill='%23f8f9fa'/%3E%3Cpath d='M300 150a50 50 0 110 100 50 50 0 010-100zm0 20a30 30 0 100 60 30 30 0 000-60z' fill='%23dee2e6'/%3E%3Cpath d='M202 298h196v40H202z' fill='%23dee2e6'/%3E%3Ctext x='300' y='325' text-anchor='middle' dominant-baseline='middle' font-family='sans-serif' font-size='14' fill='%23343a40'%3EInventory Dashboard%3C/text%3E%3C/svg%3E";
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Trusted By Section */}
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-center text-xl text-gray-600 mb-8">Trusted by leading brands worldwide</h2>
            <div className="flex flex-wrap justify-center items-center gap-12">
              <div className="w-32 h-12 flex items-center justify-center grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                <div className="text-2xl font-bold text-gray-500">ACME Inc.</div>
              </div>
              <div className="w-32 h-12 flex items-center justify-center grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                <div className="text-2xl font-bold text-gray-500">GlobalTech</div>
              </div>
              <div className="w-32 h-12 flex items-center justify-center grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                <div className="text-2xl font-bold text-gray-500">FutureCorp</div>
              </div>
              <div className="w-32 h-12 flex items-center justify-center grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                <div className="text-2xl font-bold text-gray-500">Innovex</div>
              </div>
              <div className="w-32 h-12 flex items-center justify-center grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                <div className="text-2xl font-bold text-gray-500">TechGiant</div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Key Benefits Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Key Benefits</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Why thousands of businesses choose our inventory management solution
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <Card className="text-center">
                <CardContent className="pt-6">
                  <div className="h-12 w-12 bg-primary-100 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <ShoppingCart className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Multi-Channel Integration</h3>
                  <p className="text-gray-600">
                    Seamlessly connect and manage inventory across all your sales channels, from e-commerce to retail.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="text-center">
                <CardContent className="pt-6">
                  <div className="h-12 w-12 bg-primary-100 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <BarChart2 className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Order Management</h3>
                  <p className="text-gray-600">
                    Streamline order processing, fulfillment, and tracking in one centralized system.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="text-center">
                <CardContent className="pt-6">
                  <div className="h-12 w-12 bg-primary-100 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <Clock className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Automation</h3>
                  <p className="text-gray-600">
                    Save time with automated reordering, alerts, and customizable workflow rules.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="text-center">
                <CardContent className="pt-6">
                  <div className="h-12 w-12 bg-primary-100 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <BarChart className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Reporting</h3>
                  <p className="text-gray-600">
                    Gain insights with real-time inventory analytics, valuation, and performance metrics.
                  </p>
                </CardContent>
              </Card>
            </div>
            
            <div className="text-center mt-10">
              <Button asChild>
                <Link href="/inventory/features">Explore All Features</Link>
              </Button>
            </div>
          </div>
        </section>
        
        {/* Features Overview Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Everything You Need to Manage Inventory</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Powerful tools designed to streamline your inventory operations
              </p>
            </div>
            
            <Tabs defaultValue="order-management" className="w-full">
              <TabsList className="grid grid-cols-2 md:grid-cols-4 max-w-3xl mx-auto">
                <TabsTrigger value="order-management">Order Management</TabsTrigger>
                <TabsTrigger value="inventory-control">Inventory Control</TabsTrigger>
                <TabsTrigger value="shipping">Shipping</TabsTrigger>
                <TabsTrigger value="reporting">Reporting</TabsTrigger>
              </TabsList>
              
              <TabsContent value="order-management" className="mt-8">
                <div className="flex flex-col md:flex-row bg-white rounded-lg shadow-md overflow-hidden">
                  <div className="md:w-1/2 p-8">
                    <h3 className="text-2xl font-semibold mb-4">Streamlined Order Management</h3>
                    <p className="text-gray-600 mb-6">
                      Manage all your orders from multiple channels in a single, unified platform.
                    </p>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Multi-channel order synchronization</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Purchase order management</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Sales order processing</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Order fulfillment tracking</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Backorder management</span>
                      </li>
                    </ul>
                    <Button className="mt-6" asChild>
                      <Link href="/inventory/features#order-management">Learn More</Link>
                    </Button>
                  </div>
                  <div className="md:w-1/2 bg-gray-100 flex items-center justify-center p-8">
                    <div className="w-full h-64 bg-white rounded-lg shadow-inner flex items-center justify-center">
                      <div className="text-gray-400">Order Management Dashboard</div>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="inventory-control" className="mt-8">
                <div className="flex flex-col md:flex-row bg-white rounded-lg shadow-md overflow-hidden">
                  <div className="md:w-1/2 p-8">
                    <h3 className="text-2xl font-semibold mb-4">Robust Inventory Control</h3>
                    <p className="text-gray-600 mb-6">
                      Take complete control of your inventory with real-time tracking and management tools.
                    </p>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Real-time stock tracking</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Batch and SKU management</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Automated reorder points</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Multi-warehouse management</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Barcode scanning support</span>
                      </li>
                    </ul>
                    <Button className="mt-6" asChild>
                      <Link href="/inventory/features#inventory-control">Learn More</Link>
                    </Button>
                  </div>
                  <div className="md:w-1/2 bg-gray-100 flex items-center justify-center p-8">
                    <div className="w-full h-64 bg-white rounded-lg shadow-inner flex items-center justify-center">
                      <div className="text-gray-400">Inventory Control Dashboard</div>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="shipping" className="mt-8">
                <div className="flex flex-col md:flex-row bg-white rounded-lg shadow-md overflow-hidden">
                  <div className="md:w-1/2 p-8">
                    <h3 className="text-2xl font-semibold mb-4">Integrated Shipping Solutions</h3>
                    <p className="text-gray-600 mb-6">
                      Simplify your shipping process with integrated carriers and automated tools.
                    </p>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Integrated shipping label generation</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Multiple carrier support (FedEx, UPS, USPS, DHL)</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Automated packing slips</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Shipment tracking and notifications</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Shipping rate comparison</span>
                      </li>
                    </ul>
                    <Button className="mt-6" asChild>
                      <Link href="/inventory/features#shipping">Learn More</Link>
                    </Button>
                  </div>
                  <div className="md:w-1/2 bg-gray-100 flex items-center justify-center p-8">
                    <div className="w-full h-64 bg-white rounded-lg shadow-inner flex items-center justify-center">
                      <div className="text-gray-400">Shipping Dashboard</div>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="reporting" className="mt-8">
                <div className="flex flex-col md:flex-row bg-white rounded-lg shadow-md overflow-hidden">
                  <div className="md:w-1/2 p-8">
                    <h3 className="text-2xl font-semibold mb-4">Comprehensive Reporting</h3>
                    <p className="text-gray-600 mb-6">
                      Make data-driven decisions with detailed analytics and reporting tools.
                    </p>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Real-time inventory analytics</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Inventory valuation reports</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Sales performance metrics</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Profit and loss reporting</span>
                      </li>
                      <li className="flex items-start">
                        <div className="flex-shrink-0 mr-2">
                          <Check className="h-5 w-5 text-primary" />
                        </div>
                        <span>Custom report builder</span>
                      </li>
                    </ul>
                    <Button className="mt-6" asChild>
                      <Link href="/inventory/features#reporting">Learn More</Link>
                    </Button>
                  </div>
                  <div className="md:w-1/2 bg-gray-100 flex items-center justify-center p-8">
                    <div className="w-full h-64 bg-white rounded-lg shadow-inner flex items-center justify-center">
                      <div className="text-gray-400">Reporting Dashboard</div>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>
        
        {/* Integrations Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Powerful Integrations</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Connect with your favorite tools and platforms
              </p>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
              {[
                "Shopify", "Amazon", "eBay", "WooCommerce", "QuickBooks",
                "Xero", "Zoho Books", "FedEx", "UPS", "Salesforce"
              ].map((integration, index) => (
                <div 
                  key={index} 
                  className="bg-white rounded-lg shadow-md p-4 flex flex-col items-center text-center"
                >
                  <div className="h-16 w-16 bg-gray-100 rounded-full flex items-center justify-center mb-3">
                    <div className="text-gray-400 text-lg">{integration.charAt(0)}</div>
                  </div>
                  <h3 className="text-lg font-medium mb-1">{integration}</h3>
                </div>
              ))}
            </div>
            
            <div className="text-center mt-10">
              <Button variant="outline" asChild>
                <Link href="/inventory/integrations" className="flex items-center">
                  View All Integrations <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
        
        {/* Testimonial Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">What Our Customers Say</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Real stories from businesses that transformed their inventory management
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center mb-4">
                  <div className="h-12 w-12 bg-gray-200 rounded-full mr-4 flex items-center justify-center">
                    <span className="text-gray-500 font-bold">SC</span>
                  </div>
                  <div>
                    <h4 className="font-semibold">Sarah Chen</h4>
                    <p className="text-sm text-gray-600">Retail Store Owner</p>
                  </div>
                </div>
                <p className="text-gray-700 mb-4">
                  "This inventory system has completely transformed how we manage our stock. We've reduced stockouts by 40% and saved countless hours on manual inventory tracking."
                </p>
                <div className="flex text-yellow-400">
                  {Array(5).fill(0).map((_, i) => (
                    <svg key={i} xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center mb-4">
                  <div className="h-12 w-12 bg-gray-200 rounded-full mr-4 flex items-center justify-center">
                    <span className="text-gray-500 font-bold">MB</span>
                  </div>
                  <div>
                    <h4 className="font-semibold">Michael Brown</h4>
                    <p className="text-sm text-gray-600">E-commerce Director</p>
                  </div>
                </div>
                <p className="text-gray-700 mb-4">
                  "Managing inventory across multiple channels used to be a nightmare. Now, everything syncs automatically and we can fulfill orders 3x faster. The ROI has been incredible."
                </p>
                <div className="flex text-yellow-400">
                  {Array(5).fill(0).map((_, i) => (
                    <svg key={i} xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center mb-4">
                  <div className="h-12 w-12 bg-gray-200 rounded-full mr-4 flex items-center justify-center">
                    <span className="text-gray-500 font-bold">AP</span>
                  </div>
                  <div>
                    <h4 className="font-semibold">Aisha Patel</h4>
                    <p className="text-sm text-gray-600">Manufacturing Manager</p>
                  </div>
                </div>
                <p className="text-gray-700 mb-4">
                  "The reporting tools have given us insights we never had before. We can make data-driven decisions and have saved over 20 hours per month on manual reporting tasks."
                </p>
                <div className="flex text-yellow-400">
                  {Array(5).fill(0).map((_, i) => (
                    <svg key={i} xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="text-center mt-10">
              <Button variant="outline" asChild>
                <Link href="/inventory/case-studies" className="flex items-center">
                  Read More Case Studies <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-20 bg-primary-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to streamline your inventory management?</h2>
            <p className="text-xl text-primary-100 max-w-3xl mx-auto mb-8">
              Join thousands of businesses that have transformed their operations with our powerful inventory solution.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button variant="secondary" size="lg" asChild>
                <Link href="/register">Start Free Trial</Link>
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="bg-transparent border border-white text-white hover:bg-white/10"
                asChild
              >
                <Link href="/inventory/pricing">See Pricing Plans</Link>
              </Button>
            </div>
            <p className="mt-4 text-sm text-primary-200">No credit card required. 14-day free trial.</p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default InventoryPage;