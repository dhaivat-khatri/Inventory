import { Link } from "wouter";
import { Check, X, HelpCircle } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const InventoryPricingPage = () => {
  const pricingPlans = {
    monthly: [
      {
        name: "Free",
        price: "$0",
        description: "Perfect for small businesses just getting started",
        features: [
          "Up to 50 orders per month",
          "2 sales channels",
          "Basic inventory tracking",
          "Email support",
          "Mobile app access"
        ],
        limitations: [
          "Limited to 1 user",
          "No automated reporting",
          "No batch tracking",
          "No API access"
        ],
        cta: "Start Free",
        popular: false
      },
      {
        name: "Standard",
        price: "$49",
        description: "Ideal for growing businesses with expanding needs",
        features: [
          "Up to 1,000 orders per month",
          "5 sales channels",
          "Advanced inventory tracking",
          "Batch and serial tracking",
          "Basic reporting and analytics",
          "Priority email support",
          "Mobile app access",
          "Up to 3 users"
        ],
        limitations: [
          "Limited API access",
          "Basic automation only"
        ],
        cta: "Start 14-day Trial",
        popular: true
      },
      {
        name: "Professional",
        price: "$99",
        description: "For established businesses with complex inventory needs",
        features: [
          "Up to 10,000 orders per month",
          "Unlimited sales channels",
          "Advanced inventory management",
          "Batch and serial tracking",
          "Advanced reporting and analytics",
          "Priority email & phone support",
          "Mobile app access",
          "Up to 10 users",
          "Full API access",
          "Advanced automation"
        ],
        limitations: [],
        cta: "Start 14-day Trial",
        popular: false
      },
      {
        name: "Premium",
        price: "$199",
        description: "Enterprise-grade solution for high-volume businesses",
        features: [
          "Unlimited orders",
          "Unlimited sales channels",
          "Advanced inventory management",
          "Batch and serial tracking",
          "Custom reporting and analytics",
          "24/7 dedicated support",
          "Mobile app access",
          "Unlimited users",
          "Full API access",
          "Advanced automation",
          "Dedicated account manager",
          "Custom integration development"
        ],
        limitations: [],
        cta: "Contact Sales",
        popular: false
      }
    ],
    yearly: [
      {
        name: "Free",
        price: "$0",
        description: "Perfect for small businesses just getting started",
        features: [
          "Up to 50 orders per month",
          "2 sales channels",
          "Basic inventory tracking",
          "Email support",
          "Mobile app access"
        ],
        limitations: [
          "Limited to 1 user",
          "No automated reporting",
          "No batch tracking",
          "No API access"
        ],
        cta: "Start Free",
        popular: false
      },
      {
        name: "Standard",
        price: "$39",
        period: "/mo billed annually",
        saving: "Save $120/year",
        description: "Ideal for growing businesses with expanding needs",
        features: [
          "Up to 1,000 orders per month",
          "5 sales channels",
          "Advanced inventory tracking",
          "Batch and serial tracking",
          "Basic reporting and analytics",
          "Priority email support",
          "Mobile app access",
          "Up to 3 users"
        ],
        limitations: [
          "Limited API access",
          "Basic automation only"
        ],
        cta: "Start 14-day Trial",
        popular: true
      },
      {
        name: "Professional",
        price: "$79",
        period: "/mo billed annually",
        saving: "Save $240/year",
        description: "For established businesses with complex inventory needs",
        features: [
          "Up to 10,000 orders per month",
          "Unlimited sales channels",
          "Advanced inventory management",
          "Batch and serial tracking",
          "Advanced reporting and analytics",
          "Priority email & phone support",
          "Mobile app access",
          "Up to 10 users",
          "Full API access",
          "Advanced automation"
        ],
        limitations: [],
        cta: "Start 14-day Trial",
        popular: false
      },
      {
        name: "Premium",
        price: "$159",
        period: "/mo billed annually",
        saving: "Save $480/year",
        description: "Enterprise-grade solution for high-volume businesses",
        features: [
          "Unlimited orders",
          "Unlimited sales channels",
          "Advanced inventory management",
          "Batch and serial tracking",
          "Custom reporting and analytics",
          "24/7 dedicated support",
          "Mobile app access",
          "Unlimited users",
          "Full API access",
          "Advanced automation",
          "Dedicated account manager",
          "Custom integration development"
        ],
        limitations: [],
        cta: "Contact Sales",
        popular: false
      }
    ]
  };

  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-primary-700 text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl font-bold mb-4">Simple, Transparent Pricing</h1>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Choose the plan that fits your business needs
            </p>
          </div>
        </section>

        {/* Pricing Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <Tabs defaultValue="monthly" className="w-full">
              <div className="flex justify-center mb-8">
                <TabsList>
                  <TabsTrigger value="monthly">Monthly</TabsTrigger>
                  <TabsTrigger value="yearly">Yearly (Save 20%)</TabsTrigger>
                </TabsList>
              </div>
              
              <TabsContent value="monthly">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
                  {pricingPlans.monthly.map((plan, index) => (
                    <Card 
                      key={index} 
                      className={`flex flex-col h-full ${plan.popular ? 'border-primary shadow-lg relative overflow-hidden' : ''}`}
                    >
                      {plan.popular && (
                        <div className="absolute top-0 right-0 bg-primary text-white text-xs px-3 py-1 rounded-bl-lg">
                          Most Popular
                        </div>
                      )}
                      <CardHeader className={`pb-2 text-center ${plan.popular ? 'bg-primary/5' : ''}`}>
                        <CardTitle className="text-2xl">{plan.name}</CardTitle>
                        <div className="mt-4 mb-2">
                          <span className="text-4xl font-bold">{plan.price}</span>
                          {plan.period && <span className="text-sm text-gray-500">{plan.period}</span>}
                        </div>
                        {plan.saving && (
                          <span className="inline-block bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                            {plan.saving}
                          </span>
                        )}
                        <CardDescription className="mt-3">{plan.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="flex-1">
                        <div className="space-y-4">
                          <h4 className="font-medium">Features</h4>
                          <ul className="space-y-2">
                            {plan.features.map((feature, i) => (
                              <li key={i} className="flex items-start">
                                <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                                <span className="text-sm">{feature}</span>
                              </li>
                            ))}
                          </ul>
                          
                          {plan.limitations.length > 0 && (
                            <>
                              <h4 className="font-medium mt-6">Limitations</h4>
                              <ul className="space-y-2">
                                {plan.limitations.map((limitation, i) => (
                                  <li key={i} className="flex items-start">
                                    <X className="h-5 w-5 text-red-500 mr-2 flex-shrink-0" />
                                    <span className="text-sm">{limitation}</span>
                                  </li>
                                ))}
                              </ul>
                            </>
                          )}
                        </div>
                      </CardContent>
                      <CardFooter className="pt-6">
                        <Button 
                          className={`w-full ${plan.popular ? 'bg-primary hover:bg-primary-600' : ''}`}
                          variant={plan.name === "Premium" ? "outline" : "default"}
                          asChild
                        >
                          <Link href={plan.name === "Premium" ? "/contact" : "/register"}>
                            {plan.cta}
                          </Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="yearly">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
                  {pricingPlans.yearly.map((plan, index) => (
                    <Card 
                      key={index} 
                      className={`flex flex-col h-full ${plan.popular ? 'border-primary shadow-lg relative overflow-hidden' : ''}`}
                    >
                      {plan.popular && (
                        <div className="absolute top-0 right-0 bg-primary text-white text-xs px-3 py-1 rounded-bl-lg">
                          Most Popular
                        </div>
                      )}
                      <CardHeader className={`pb-2 text-center ${plan.popular ? 'bg-primary/5' : ''}`}>
                        <CardTitle className="text-2xl">{plan.name}</CardTitle>
                        <div className="mt-4 mb-2">
                          <span className="text-4xl font-bold">{plan.price}</span>
                          {plan.period && <span className="text-sm text-gray-500">{plan.period}</span>}
                        </div>
                        {plan.saving && (
                          <span className="inline-block bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                            {plan.saving}
                          </span>
                        )}
                        <CardDescription className="mt-3">{plan.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="flex-1">
                        <div className="space-y-4">
                          <h4 className="font-medium">Features</h4>
                          <ul className="space-y-2">
                            {plan.features.map((feature, i) => (
                              <li key={i} className="flex items-start">
                                <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                                <span className="text-sm">{feature}</span>
                              </li>
                            ))}
                          </ul>
                          
                          {plan.limitations.length > 0 && (
                            <>
                              <h4 className="font-medium mt-6">Limitations</h4>
                              <ul className="space-y-2">
                                {plan.limitations.map((limitation, i) => (
                                  <li key={i} className="flex items-start">
                                    <X className="h-5 w-5 text-red-500 mr-2 flex-shrink-0" />
                                    <span className="text-sm">{limitation}</span>
                                  </li>
                                ))}
                              </ul>
                            </>
                          )}
                        </div>
                      </CardContent>
                      <CardFooter className="pt-6">
                        <Button 
                          className={`w-full ${plan.popular ? 'bg-primary hover:bg-primary-600' : ''}`}
                          variant={plan.name === "Premium" ? "outline" : "default"}
                          asChild
                        >
                          <Link href={plan.name === "Premium" ? "/contact" : "/register"}>
                            {plan.cta}
                          </Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* Add-Ons Section */}
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Add-Ons</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Enhance your inventory management with additional capabilities
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <Card>
                <CardHeader>
                  <CardTitle>Additional Users</CardTitle>
                  <CardDescription>Add more team members to your account</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold mb-2">$10<span className="text-sm text-gray-500">/user/month</span></p>
                  <p className="text-sm text-gray-600">
                    Expand access to your inventory system for your growing team with additional user accounts.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/contact">Contact Sales</Link>
                  </Button>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Advanced Reporting</CardTitle>
                  <CardDescription>Enhanced analytics and custom reports</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold mb-2">$29<span className="text-sm text-gray-500">/month</span></p>
                  <p className="text-sm text-gray-600">
                    Gain deeper insights with advanced reporting tools, custom dashboards, and data visualization.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/contact">Contact Sales</Link>
                  </Button>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Premium Support</CardTitle>
                  <CardDescription>Priority assistance and training</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold mb-2">$49<span className="text-sm text-gray-500">/month</span></p>
                  <p className="text-sm text-gray-600">
                    Get dedicated support, faster response times, and personalized training sessions.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href="/contact">Contact Sales</Link>
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Find answers to common questions about our pricing and plans
              </p>
            </div>
            
            <div className="max-w-3xl mx-auto">
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger>How do I know which plan is right for my business?</AccordionTrigger>
                  <AccordionContent>
                    The best plan depends on your business size, order volume, and feature needs. The Free plan works well for very small businesses, Standard is great for growing businesses, Professional suits established companies with complex inventory needs, and Premium is designed for high-volume enterprise operations. Still unsure? Contact our sales team for personalized guidance.
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-2">
                  <AccordionTrigger>Can I change plans as my business grows?</AccordionTrigger>
                  <AccordionContent>
                    Yes! You can upgrade or downgrade your plan at any time. When upgrading, the new plan takes effect immediately. When downgrading, the change will apply at the start of your next billing cycle.
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-3">
                  <AccordionTrigger>How does the 14-day free trial work?</AccordionTrigger>
                  <AccordionContent>
                    Our 14-day free trial gives you full access to all features of the selected plan. No credit card is required to start, and you'll receive a reminder before the trial ends. If you choose not to continue, your account will automatically downgrade to the Free plan with no charge.
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-4">
                  <AccordionTrigger>What payment methods do you accept?</AccordionTrigger>
                  <AccordionContent>
                    We accept all major credit cards (Visa, Mastercard, American Express, Discover), as well as PayPal. For annual plans, we can also arrange payment via bank transfer.
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-5">
                  <AccordionTrigger>Is there a setup fee?</AccordionTrigger>
                  <AccordionContent>
                    No, there are no setup fees for any of our plans. You only pay the advertised monthly or annual subscription price.
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-6">
                  <AccordionTrigger>Do you offer custom plans for large enterprises?</AccordionTrigger>
                  <AccordionContent>
                    Yes, we offer custom enterprise solutions for businesses with specific requirements. Contact our sales team to discuss your needs and receive a tailored proposal.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          </div>
        </section>

        {/* Compare Plans Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Compare Plans</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                See which features are included in each plan
              </p>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full bg-white rounded-lg shadow-md">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="p-4 text-left">Features</th>
                    <th className="p-4 text-center">Free</th>
                    <th className="p-4 text-center">Standard</th>
                    <th className="p-4 text-center">Professional</th>
                    <th className="p-4 text-center">Premium</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="p-4 font-medium">Monthly Orders</td>
                    <td className="p-4 text-center">Up to 50</td>
                    <td className="p-4 text-center">Up to 1,000</td>
                    <td className="p-4 text-center">Up to 10,000</td>
                    <td className="p-4 text-center">Unlimited</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4 font-medium">Sales Channels</td>
                    <td className="p-4 text-center">2</td>
                    <td className="p-4 text-center">5</td>
                    <td className="p-4 text-center">Unlimited</td>
                    <td className="p-4 text-center">Unlimited</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4 font-medium">Users</td>
                    <td className="p-4 text-center">1</td>
                    <td className="p-4 text-center">Up to 3</td>
                    <td className="p-4 text-center">Up to 10</td>
                    <td className="p-4 text-center">Unlimited</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4 font-medium">Batch & Serial Tracking</td>
                    <td className="p-4 text-center">
                      <X className="h-5 w-5 text-red-500 mx-auto" />
                    </td>
                    <td className="p-4 text-center">
                      <Check className="h-5 w-5 text-green-500 mx-auto" />
                    </td>
                    <td className="p-4 text-center">
                      <Check className="h-5 w-5 text-green-500 mx-auto" />
                    </td>
                    <td className="p-4 text-center">
                      <Check className="h-5 w-5 text-green-500 mx-auto" />
                    </td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4 font-medium">API Access</td>
                    <td className="p-4 text-center">
                      <X className="h-5 w-5 text-red-500 mx-auto" />
                    </td>
                    <td className="p-4 text-center">Limited</td>
                    <td className="p-4 text-center">Full</td>
                    <td className="p-4 text-center">Full</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4 font-medium">Automation</td>
                    <td className="p-4 text-center">
                      <X className="h-5 w-5 text-red-500 mx-auto" />
                    </td>
                    <td className="p-4 text-center">Basic</td>
                    <td className="p-4 text-center">Advanced</td>
                    <td className="p-4 text-center">Advanced</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4 font-medium">Reporting & Analytics</td>
                    <td className="p-4 text-center">Basic</td>
                    <td className="p-4 text-center">Standard</td>
                    <td className="p-4 text-center">Advanced</td>
                    <td className="p-4 text-center">Custom</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4 font-medium">Support</td>
                    <td className="p-4 text-center">Email</td>
                    <td className="p-4 text-center">Priority Email</td>
                    <td className="p-4 text-center">Email & Phone</td>
                    <td className="p-4 text-center">24/7 Dedicated</td>
                  </tr>
                  <tr>
                    <td className="p-4 font-medium">Custom Integrations</td>
                    <td className="p-4 text-center">
                      <X className="h-5 w-5 text-red-500 mx-auto" />
                    </td>
                    <td className="p-4 text-center">
                      <X className="h-5 w-5 text-red-500 mx-auto" />
                    </td>
                    <td className="p-4 text-center">
                      <X className="h-5 w-5 text-red-500 mx-auto" />
                    </td>
                    <td className="p-4 text-center">
                      <Check className="h-5 w-5 text-green-500 mx-auto" />
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-primary-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to get started?</h2>
            <p className="text-xl text-primary-100 max-w-3xl mx-auto mb-8">
              Choose the plan that's right for your business and start streamlining your inventory management today.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button variant="secondary" size="lg" asChild>
                <Link href="/register">Start Free Trial</Link>
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="bg-transparent border border-white text-white hover:bg-white/10"
                asChild
              >
                <Link href="/contact">Contact Sales</Link>
              </Button>
            </div>
            <p className="mt-4 text-sm text-primary-200">No credit card required. 14-day free trial.</p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default InventoryPricingPage;