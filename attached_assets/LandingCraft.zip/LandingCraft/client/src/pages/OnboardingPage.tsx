import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Check, ChevronRight, Loader2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "@/hooks/use-toast";

const OnboardingPage = () => {
  const [location, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const [totalSteps] = useState(4);
  const [formData, setFormData] = useState({
    businessType: "",
    productCount: "",
    channelCount: "",
    integrations: [] as string[]
  });
  
  // Query for user data
  const { data: user, isLoading: userLoading, error: userError } = useQuery({
    queryKey: ['/api/auth/me'],
    retry: false,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
  
  // Update onboarding status mutation
  const completeOnboardingMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('/api/auth/onboarding', {
        method: 'PUT',
        body: { 
          onboardingCompleted: true,
          dashboardPreferences: {
            ...formData
          }
        }
      });
    },
    onSuccess: () => {
      // Invalidate user query
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      // Redirect to dashboard
      setLocation('/dashboard');
      toast({
        title: "Onboarding completed",
        description: "Welcome to your personalized dashboard!",
        variant: "default",
      });
    },
  });
  
  // Effect to check if user is already authenticated and has completed onboarding
  useEffect(() => {
    if (user && user.onboardingCompleted) {
      setLocation('/dashboard');
    } else if (userError) {
      setLocation('/signin');
    }
  }, [user, userError, setLocation]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleRadioChange = (value: string, field: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };
  
  const toggleIntegration = (integration: string) => {
    setFormData(prev => {
      const integrations = [...prev.integrations];
      if (integrations.includes(integration)) {
        return {
          ...prev,
          integrations: integrations.filter(i => i !== integration)
        };
      } else {
        return {
          ...prev,
          integrations: [...integrations, integration]
        };
      }
    });
  };
  
  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    } else {
      completeOnboardingMutation.mutate();
    }
  };
  
  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };
  
  if (userLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-500">Loading...</p>
        </div>
      </div>
    );
  }
  
  const isStepComplete = () => {
    switch (step) {
      case 1:
        return formData.businessType !== "";
      case 2:
        return formData.productCount !== "";
      case 3:
        return formData.channelCount !== "";
      case 4:
        return true; // Integrations are optional
      default:
        return false;
    }
  };
  
  // List of available integrations
  const availableIntegrations = [
    { id: 'shopify', name: 'Shopify', category: 'E-commerce Platform' },
    { id: 'amazon', name: 'Amazon', category: 'Marketplace' },
    { id: 'quickbooks', name: 'QuickBooks', category: 'Accounting' },
    { id: 'xero', name: 'Xero', category: 'Accounting' },
    { id: 'fedex', name: 'FedEx', category: 'Shipping' },
    { id: 'ups', name: 'UPS', category: 'Shipping' },
    { id: 'woocommerce', name: 'WooCommerce', category: 'E-commerce Platform' },
    { id: 'zohocrm', name: 'Zoho CRM', category: 'CRM' },
  ];
  
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50 p-4">
      <Card className="max-w-4xl w-full p-6 md:p-8 bg-white shadow-lg rounded-xl">
        <div className="mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="text-primary font-bold text-3xl">
              <span className="text-primary">Biz</span>Suite
            </div>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-center">Welcome to your Inventory Dashboard</h1>
          <p className="text-gray-500 text-center mt-2">Let's set up your account in a few simple steps</p>
          
          {/* Progress Bar */}
          <div className="mt-8 mb-4">
            <div className="h-2 w-full bg-gray-100 rounded-full">
              <div 
                className="h-2 bg-primary rounded-full transition-all duration-300"
                style={{ width: `${(step / totalSteps) * 100}%` }}
              ></div>
            </div>
            <div className="flex justify-between mt-2 text-sm text-gray-500">
              <span>Start</span>
              <span>Finish</span>
            </div>
          </div>
        </div>
        
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            {step === 1 && (
              <div>
                <h2 className="text-xl font-semibold mb-6">Tell us about your business</h2>
                <div className="space-y-4">
                  <RadioGroup 
                    value={formData.businessType} 
                    onValueChange={(value) => handleRadioChange(value, 'businessType')}
                  >
                    <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                      <RadioGroupItem value="ecommerce" id="ecommerce" />
                      <Label htmlFor="ecommerce" className="flex-1 cursor-pointer">E-commerce Business</Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                      <RadioGroupItem value="retail" id="retail" />
                      <Label htmlFor="retail" className="flex-1 cursor-pointer">Retail Store</Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                      <RadioGroupItem value="wholesale" id="wholesale" />
                      <Label htmlFor="wholesale" className="flex-1 cursor-pointer">Wholesale Distributor</Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                      <RadioGroupItem value="manufacturing" id="manufacturing" />
                      <Label htmlFor="manufacturing" className="flex-1 cursor-pointer">Manufacturing</Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                      <RadioGroupItem value="other" id="other" />
                      <Label htmlFor="other" className="flex-1 cursor-pointer">Other</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            )}
            
            {step === 2 && (
              <div>
                <h2 className="text-xl font-semibold mb-6">How many products do you manage?</h2>
                <div className="space-y-4">
                  <RadioGroup 
                    value={formData.productCount} 
                    onValueChange={(value) => handleRadioChange(value, 'productCount')}
                  >
                    <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                      <RadioGroupItem value="0-10" id="0-10" />
                      <Label htmlFor="0-10" className="flex-1 cursor-pointer">Less than 10</Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                      <RadioGroupItem value="11-50" id="11-50" />
                      <Label htmlFor="11-50" className="flex-1 cursor-pointer">11 - 50</Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                      <RadioGroupItem value="51-200" id="51-200" />
                      <Label htmlFor="51-200" className="flex-1 cursor-pointer">51 - 200</Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                      <RadioGroupItem value="201-1000" id="201-1000" />
                      <Label htmlFor="201-1000" className="flex-1 cursor-pointer">201 - 1,000</Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                      <RadioGroupItem value="1000+" id="1000+" />
                      <Label htmlFor="1000+" className="flex-1 cursor-pointer">More than 1,000</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            )}
            
            {step === 3 && (
              <div>
                <h2 className="text-xl font-semibold mb-6">Where do you sell your products?</h2>
                <div className="space-y-4">
                  <RadioGroup 
                    value={formData.channelCount} 
                    onValueChange={(value) => handleRadioChange(value, 'channelCount')}
                  >
                    <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                      <RadioGroupItem value="single-channel" id="single-channel" />
                      <Label htmlFor="single-channel" className="flex-1 cursor-pointer">
                        <div>Single Channel</div>
                        <div className="text-sm text-gray-500">Only one store or marketplace</div>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                      <RadioGroupItem value="multi-channel" id="multi-channel" />
                      <Label htmlFor="multi-channel" className="flex-1 cursor-pointer">
                        <div>Multi-Channel</div>
                        <div className="text-sm text-gray-500">2-5 sales channels</div>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                      <RadioGroupItem value="omni-channel" id="omni-channel" />
                      <Label htmlFor="omni-channel" className="flex-1 cursor-pointer">
                        <div>Omni-Channel</div>
                        <div className="text-sm text-gray-500">More than 5 sales channels</div>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            )}
            
            {step === 4 && (
              <div>
                <h2 className="text-xl font-semibold mb-6">Which platforms would you like to integrate?</h2>
                <p className="text-gray-500 mb-4">Select the platforms you're currently using or planning to use.</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {availableIntegrations.map(integration => (
                    <div 
                      key={integration.id}
                      className={`flex items-center p-4 border rounded-lg cursor-pointer transition-colors ${
                        formData.integrations.includes(integration.id) ? 'border-primary bg-primary-50' : 'hover:bg-gray-50'
                      }`}
                      onClick={() => toggleIntegration(integration.id)}
                    >
                      <div className={`h-8 w-8 rounded-full bg-gray-100 flex items-center justify-center mr-3 ${
                        formData.integrations.includes(integration.id) ? 'bg-primary text-white' : ''
                      }`}>
                        {formData.integrations.includes(integration.id) ? 
                          <Check className="h-5 w-5" /> : integration.name.charAt(0)
                        }
                      </div>
                      <div>
                        <p className="font-medium">{integration.name}</p>
                        <p className="text-xs text-gray-500">{integration.category}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <p className="text-gray-500 mt-4 text-sm">Don't worry, you can always add or remove integrations later.</p>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
        
        <div className="mt-8 flex justify-between">
          <Button 
            variant="outline" 
            onClick={handleBack}
            disabled={step === 1}
          >
            Back
          </Button>
          
          <Button 
            onClick={handleNext}
            disabled={!isStepComplete() || completeOnboardingMutation.isPending}
          >
            {completeOnboardingMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processing...
              </>
            ) : step < totalSteps ? (
              <>
                Next
                <ChevronRight className="ml-2 h-4 w-4" />
              </>
            ) : (
              'Complete Setup'
            )}
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default OnboardingPage;