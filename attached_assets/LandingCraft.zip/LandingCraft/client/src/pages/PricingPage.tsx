import Header from "@/components/Header";
import PricingSection from "@/components/PricingSection";
import CTA from "@/components/CTA";
import Footer from "@/components/Footer";

const PricingPage = () => {
  return (
    <>
      <Header />
      <div className="bg-gray-50 py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">Pricing Plans</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Simple, transparent pricing for businesses of all sizes. Choose the plan that works best for you.
          </p>
        </div>
      </div>
      <PricingSection />
      <div className="container mx-auto px-4 py-12">
        <div className="bg-white rounded-lg shadow-md p-8 border border-gray-200">
          <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-2">Can I switch plans later?</h3>
              <p className="text-gray-600">Yes, you can upgrade or downgrade your plan at any time. When you upgrade, the new pricing takes effect immediately. When you downgrade, the new pricing takes effect at the start of your next billing cycle.</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">What happens when my trial ends?</h3>
              <p className="text-gray-600">When your 14-day free trial ends, your account will automatically switch to the Free plan unless you choose to upgrade to a paid plan. You won't lose any of your data.</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Do you offer discounts for nonprofits?</h3>
              <p className="text-gray-600">Yes, we offer special pricing for eligible nonprofit organizations. Please contact our sales team for more information.</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Is there a setup fee?</h3>
              <p className="text-gray-600">No, there are no setup fees for any of our plans. You only pay the advertised price.</p>
            </div>
          </div>
        </div>
      </div>
      <CTA />
      <Footer />
    </>
  );
};

export default PricingPage;
