import { useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { ArrowRight, Check } from "lucide-react";
import { Link } from "wouter";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { ProductIcons } from "@/lib/icons";

// Define the product data
const productsData = {
  "crm": {
    title: "CRM",
    icon: "users",
    description: "Build stronger customer relationships with a complete view of your customers, streamlined sales processes, and powerful analytics.",
    features: [
      "Contact and lead management",
      "Sales pipeline tracking",
      "Email integration",
      "Task and activity management",
      "Customer insights and analytics",
      "Custom reporting dashboards"
    ],
    benefits: [
      "Increase sales conversion rates",
      "Improve customer retention",
      "Streamline sales processes",
      "Make data-driven decisions"
    ]
  },
  "email-marketing": {
    title: "Email Marketing",
    icon: "mail",
    description: "Create, send, and analyze email campaigns that drive engagement and conversions with our intuitive email marketing tools.",
    features: [
      "Drag-and-drop email builder",
      "Automated email sequences",
      "A/B testing",
      "Audience segmentation",
      "Detailed analytics",
      "Integration with CRM"
    ],
    benefits: [
      "Increase email engagement",
      "Drive more conversions",
      "Save time with automation",
      "Personalize communication"
    ]
  },
  "finance": {
    title: "Finance",
    icon: "chart",
    description: "Simplify accounting, invoicing, expenses, and financial reporting with our comprehensive finance solutions.",
    features: [
      "Double-entry accounting",
      "Invoicing and estimates",
      "Expense tracking",
      "Bank reconciliation",
      "Financial reporting",
      "Tax preparation"
    ],
    benefits: [
      "Streamline financial operations",
      "Get paid faster",
      "Simplify tax compliance",
      "Gain financial insights"
    ]
  },
  "hr": {
    title: "HR Management",
    icon: "user",
    description: "Manage the entire employee lifecycle from recruitment to retirement with our powerful HR tools.",
    features: [
      "Applicant tracking",
      "Onboarding automation",
      "Time and attendance",
      "Performance management",
      "Employee self-service",
      "HR analytics"
    ],
    benefits: [
      "Streamline recruitment",
      "Reduce HR administration",
      "Improve employee experience",
      "Make data-driven HR decisions"
    ]
  },
  "project-management": {
    title: "Project Management",
    icon: "tasks",
    description: "Plan, track, and deliver projects on time and within budget with our collaborative project management software.",
    features: [
      "Task and subtask management",
      "Gantt charts and timelines",
      "Resource allocation",
      "Time tracking",
      "Project templates",
      "Progress reporting"
    ],
    benefits: [
      "Deliver projects on time",
      "Stay within budget",
      "Improve team collaboration",
      "Track project progress"
    ]
  },
  "customer-support": {
    title: "Customer Support",
    icon: "headset",
    description: "Provide exceptional customer service with our help desk, live chat, and knowledge base solutions.",
    features: [
      "Ticketing system",
      "Live chat",
      "Knowledge base",
      "Customer portal",
      "Automated workflows",
      "SLA management"
    ],
    benefits: [
      "Improve response times",
      "Increase customer satisfaction",
      "Reduce support costs",
      "Scale support operations"
    ]
  }
};

// Product type for TypeScript
type ProductKey = keyof typeof productsData;

const ProductPage = () => {
  const [match, params] = useRoute("/products/:productId");
  const [, setLocation] = useLocation();
  
  // Extract the product ID from the URL
  const productId = params?.productId as ProductKey;
  
  // Get the product data
  const product = productsData[productId];
  
  // Redirect to 404 if product doesn't exist
  useEffect(() => {
    if (!match || !product) {
      setLocation("/not-found");
    }
  }, [match, product, setLocation]);
  
  // Return nothing while redirecting
  if (!product) {
    return null;
  }

  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-primary-700 text-white py-16">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-2/3 mb-8 md:mb-0">
                <h1 className="text-4xl font-bold mb-4">{product.title}</h1>
                <p className="text-xl mb-8 text-primary-100">{product.description}</p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button variant="secondary" size="lg" asChild>
                    <Link href="/register">Start Free Trial</Link>
                  </Button>
                  <Button variant="outline" size="lg" className="bg-transparent border border-white text-white hover:bg-white/10" asChild>
                    <Link href="/demo">Watch Demo</Link>
                  </Button>
                </div>
                <p className="mt-4 text-sm text-primary-100">No credit card required. 14-day free trial.</p>
              </div>
              <div className="md:w-1/3 flex justify-center">
                <div className="w-32 h-32 bg-white/10 rounded-full flex items-center justify-center text-white">
                  {ProductIcons[product.icon]}
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Features Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Key Features</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Everything you need in one powerful, easy-to-use solution.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {product.features.map((feature, index) => (
                <div 
                  key={index}
                  className="bg-white rounded-lg shadow-md p-6 border border-gray-100"
                >
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mr-4">
                      <div className="h-8 w-8 bg-primary-100 text-primary rounded-full flex items-center justify-center">
                        <Check className="h-4 w-4" />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">{feature}</h3>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        {/* Benefits Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Benefits</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Why businesses choose our {product.title} solution.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {product.benefits.map((benefit, index) => (
                <div 
                  key={index}
                  className="bg-white rounded-lg shadow-md p-6 border border-gray-100"
                >
                  <h3 className="text-xl font-semibold mb-4">{benefit}</h3>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-16 bg-primary-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to get started with {product.title}?</h2>
            <p className="text-xl text-primary-100 max-w-3xl mx-auto mb-8">
              Join thousands of businesses that trust our {product.title} solution.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button variant="secondary" size="lg" asChild>
                <Link href="/register">Start Free Trial</Link>
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="bg-transparent border border-white text-white hover:bg-white/10"
                asChild
              >
                <Link href="/contact">Talk to Sales</Link>
              </Button>
            </div>
            <p className="mt-4 text-sm text-primary-200">No credit card required. 14-day free trial.</p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default ProductPage;