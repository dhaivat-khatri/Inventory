import { useState } from "react";
import { Link } from "wouter";
import { Search, ArrowRight, Filter } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

// Define resource data
const resourcesData = [
  {
    id: 1,
    title: "The Ultimate Guide to CRM Implementation",
    description: "Learn how to successfully implement a CRM system in your organization with this comprehensive guide.",
    image: "/img/resources/crm-guide.jpg",
    category: "guide",
    date: "March 10, 2025",
    readTime: "10 min read"
  },
  {
    id: 2,
    title: "5 Ways to Improve Customer Retention",
    description: "Discover proven strategies to increase customer loyalty and reduce churn in your business.",
    image: "/img/resources/customer-retention.jpg",
    category: "article",
    date: "March 5, 2025",
    readTime: "7 min read"
  },
  {
    id: 3,
    title: "Email Marketing Best Practices for 2025",
    description: "Stay ahead of the curve with these email marketing tips and strategies for the new year.",
    image: "/img/resources/email-marketing.jpg",
    category: "article",
    date: "February 28, 2025",
    readTime: "8 min read"
  },
  {
    id: 4,
    title: "How to Automate Your Sales Process",
    description: "Learn how to leverage automation to streamline your sales process and close more deals.",
    image: "/img/resources/sales-automation.jpg",
    category: "guide",
    date: "February 20, 2025",
    readTime: "12 min read"
  },
  {
    id: 5,
    title: "The ROI of Cloud-Based Business Solutions",
    description: "Understand the financial benefits of moving your business operations to the cloud.",
    image: "/img/resources/cloud-roi.jpg",
    category: "whitepaper",
    date: "February 15, 2025",
    readTime: "15 min read"
  },
  {
    id: 6,
    title: "Digital Transformation Success Stories",
    description: "Real-world examples of companies that successfully transformed their operations through technology.",
    image: "/img/resources/digital-transformation.jpg",
    category: "case-study",
    date: "February 10, 2025",
    readTime: "9 min read"
  },
  {
    id: 7,
    title: "Building a Data-Driven Culture",
    description: "Steps to foster a data-driven decision-making culture in your organization.",
    image: "/img/resources/data-culture.jpg",
    category: "guide",
    date: "February 5, 2025",
    readTime: "11 min read"
  },
  {
    id: 8,
    title: "HR Management in the Remote Work Era",
    description: "Strategies for effective HR management in distributed and remote-first teams.",
    image: "/img/resources/remote-hr.jpg",
    category: "article",
    date: "January 30, 2025",
    readTime: "8 min read"
  }
];

// Define webinars data
const webinarsData = [
  {
    id: 1,
    title: "Mastering Customer Experience in 2025",
    description: "Join our expert panel to learn about the latest trends and strategies in customer experience management.",
    date: "March 25, 2025",
    time: "11:00 AM EST",
    speakers: ["Sarah Johnson, CX Specialist", "Mark Williams, Product Manager"]
  },
  {
    id: 2,
    title: "AI-Powered Sales: From Leads to Closed Deals",
    description: "Discover how artificial intelligence is revolutionizing the sales process and how you can leverage it.",
    date: "April 2, 2025",
    time: "2:00 PM EST",
    speakers: ["David Chen, AI Strategist", "Lisa Turner, Sales Director"]
  },
  {
    id: 3,
    title: "Financial Forecasting for Growing Businesses",
    description: "Learn practical techniques for accurate financial forecasting to drive business growth.",
    date: "April 10, 2025",
    time: "1:00 PM EST",
    speakers: ["Robert Garcia, Financial Analyst", "Emma Lewis, Business Consultant"]
  }
];

const ResourcesPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  
  // Filter resources based on search query and active tab
  const filteredResources = resourcesData.filter(resource => {
    const matchesSearch = resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          resource.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTab = activeTab === "all" || resource.category === activeTab;
    
    return matchesSearch && matchesTab;
  });

  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-primary-700 text-white py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl font-bold mb-4">Resources & Learning Center</h1>
              <p className="text-xl mb-8 text-primary-100">
                Explore our comprehensive collection of guides, articles, case studies, and webinars to help your business grow.
              </p>
              <div className="relative max-w-2xl mx-auto">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <Input 
                  type="text"
                  placeholder="Search resources..."
                  className="pl-10 bg-white text-gray-900 placeholder-gray-500"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
          </div>
        </section>
        
        {/* Resources Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <Tabs defaultValue="all" className="w-full" onValueChange={setActiveTab}>
              <div className="flex justify-between items-center mb-8 flex-wrap gap-4">
                <TabsList>
                  <TabsTrigger value="all">All Resources</TabsTrigger>
                  <TabsTrigger value="article">Articles</TabsTrigger>
                  <TabsTrigger value="guide">Guides</TabsTrigger>
                  <TabsTrigger value="whitepaper">Whitepapers</TabsTrigger>
                  <TabsTrigger value="case-study">Case Studies</TabsTrigger>
                </TabsList>
                <div className="flex items-center">
                  <Button variant="outline" size="sm" className="gap-2">
                    <Filter className="h-4 w-4" />
                    Filter
                  </Button>
                </div>
              </div>
              
              <TabsContent value="all" className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {filteredResources.map(resource => (
                    <div key={resource.id} className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 flex flex-col">
                      <div className="h-48 bg-gray-200 flex items-center justify-center">
                        <div className="text-gray-400">Resource Image</div>
                      </div>
                      <div className="p-6 flex flex-col flex-grow">
                        <div className="flex justify-between items-center mb-3">
                          <Badge variant="outline" className="text-xs">
                            {resource.category.charAt(0).toUpperCase() + resource.category.slice(1)}
                          </Badge>
                          <span className="text-xs text-gray-500">{resource.readTime}</span>
                        </div>
                        <h3 className="text-xl font-semibold mb-2">{resource.title}</h3>
                        <p className="text-gray-600 mb-4 flex-grow">{resource.description}</p>
                        <div className="flex justify-between items-center mt-auto">
                          <span className="text-xs text-gray-500">{resource.date}</span>
                          <Link href={`/resources/${resource.id}`} className="text-primary hover:text-primary-700 font-medium flex items-center gap-1">
                            Read more
                            <ArrowRight className="h-4 w-4" />
                          </Link>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                {filteredResources.length === 0 && (
                  <div className="text-center py-12">
                    <h3 className="text-xl font-semibold mb-2">No resources found</h3>
                    <p className="text-gray-600">Try adjusting your search or filter criteria.</p>
                  </div>
                )}
              </TabsContent>
              
              {/* Duplicate similar TabsContent for other tabs */}
            </Tabs>
          </div>
        </section>
        
        {/* Upcoming Webinars Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Upcoming Webinars</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Join our live sessions with industry experts and learn about the latest trends and best practices.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {webinarsData.map(webinar => (
                <div key={webinar.id} className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
                  <div className="mb-4 text-primary font-medium">{webinar.date} • {webinar.time}</div>
                  <h3 className="text-xl font-semibold mb-2">{webinar.title}</h3>
                  <p className="text-gray-600 mb-4">{webinar.description}</p>
                  <div className="mb-4">
                    <h4 className="font-medium text-sm text-gray-700 mb-2">Speakers:</h4>
                    <ul className="text-gray-600 text-sm">
                      {webinar.speakers.map((speaker, idx) => (
                        <li key={idx} className="mb-1">{speaker}</li>
                      ))}
                    </ul>
                  </div>
                  <Button className="w-full">Register Now</Button>
                </div>
              ))}
            </div>
            
            <div className="text-center mt-10">
              <Link href="/webinars" className="text-primary hover:text-primary-700 font-medium flex items-center gap-1 justify-center">
                View all webinars
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </section>
        
        {/* Newsletter Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl font-bold mb-4">Stay Updated</h2>
              <p className="text-xl text-gray-600 mb-8">
                Subscribe to our newsletter to receive the latest resources, webinars, and industry insights.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
                <Input 
                  type="email"
                  placeholder="Your email address"
                  className="flex-grow"
                />
                <Button className="whitespace-nowrap">Subscribe</Button>
              </div>
              <p className="text-sm text-gray-500 mt-4">
                By subscribing, you agree to our Privacy Policy and consent to receive updates from our company.
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default ResourcesPage;