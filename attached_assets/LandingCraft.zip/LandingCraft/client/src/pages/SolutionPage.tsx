import { useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { ArrowRight, Check } from "lucide-react";
import { Link } from "wouter";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";

// Define the solution data categories
const solutionsData = {
  // By Industry
  "financial-services": {
    title: "Financial Services",
    category: "industry",
    description: "Secure, compliant solutions for banks, insurance companies, and financial institutions.",
    challenges: [
      "Meeting regulatory compliance requirements",
      "Protecting sensitive customer data",
      "Streamlining complex operations",
      "Delivering personalized customer experiences"
    ],
    benefits: [
      "Ensure regulatory compliance with built-in controls",
      "Enhance data security with advanced protection",
      "Reduce operational costs through automation",
      "Provide seamless customer experiences across channels"
    ],
    features: [
      "Compliance management",
      "Secure client portals",
      "Automated workflows",
      "Customer relationship management"
    ]
  },
  "healthcare": {
    title: "Healthcare",
    category: "industry",
    description: "HIPAA-compliant tools for healthcare providers, hospitals, and medical practices.",
    challenges: [
      "Maintaining HIPAA compliance",
      "Managing patient records securely",
      "Coordinating care across departments",
      "Optimizing administrative processes"
    ],
    benefits: [
      "Ensure HIPAA compliance with built-in safeguards",
      "Securely manage electronic health records",
      "Improve care coordination and communication",
      "Reduce administrative burden through automation"
    ],
    features: [
      "HIPAA-compliant data storage",
      "Secure patient portals",
      "Practice management tools",
      "Billing and claims processing"
    ]
  },
  "manufacturing": {
    title: "Manufacturing",
    category: "industry",
    description: "Streamline operations and optimize production with specialized tools for manufacturers.",
    challenges: [
      "Managing complex supply chains",
      "Optimizing production processes",
      "Maintaining quality control",
      "Reducing operational costs"
    ],
    benefits: [
      "Gain visibility across your entire supply chain",
      "Optimize production schedules and resources",
      "Ensure consistent product quality",
      "Reduce costs through process automation"
    ],
    features: [
      "Supply chain management",
      "Production planning",
      "Quality control systems",
      "Inventory optimization"
    ]
  },
  "retail": {
    title: "Retail",
    category: "industry",
    description: "Omnichannel solutions for retailers to manage inventory, sales, and customer relationships.",
    challenges: [
      "Managing inventory across multiple channels",
      "Delivering consistent customer experiences",
      "Analyzing sales and customer data",
      "Optimizing pricing and promotions"
    ],
    benefits: [
      "Centralize inventory management across channels",
      "Create seamless customer experiences",
      "Gain actionable insights from data",
      "Optimize pricing strategies for profit"
    ],
    features: [
      "Inventory management",
      "Point of sale integration",
      "Customer loyalty programs",
      "Analytics and reporting"
    ]
  },
  
  // By Business Size
  "small-business": {
    title: "Small Business",
    category: "size",
    description: "Affordable, easy-to-use solutions for small businesses with 1-50 employees.",
    challenges: [
      "Limited budget and resources",
      "Wearing multiple hats in the business",
      "Competing with larger companies",
      "Scaling operations efficiently"
    ],
    benefits: [
      "Access enterprise-grade tools at affordable prices",
      "Automate manual tasks to free up your time",
      "Compete effectively with larger businesses",
      "Scale your operations as you grow"
    ],
    features: [
      "Essential business applications",
      "Pay-as-you-grow pricing",
      "Easy setup and onboarding",
      "Mobile access"
    ]
  },
  "mid-market": {
    title: "Mid-Market",
    category: "size",
    description: "Scalable solutions for growing businesses with 50-500 employees.",
    challenges: [
      "Managing rapid growth",
      "Standardizing processes",
      "Gaining visibility across departments",
      "Optimizing resource allocation"
    ],
    benefits: [
      "Support your growth with flexible solutions",
      "Standardize processes for efficiency",
      "Gain a complete view of your business",
      "Optimize resources for maximum ROI"
    ],
    features: [
      "Comprehensive business suite",
      "Advanced automation",
      "Cross-departmental integration",
      "Custom reporting"
    ]
  },
  "enterprise": {
    title: "Enterprise",
    category: "size",
    description: "Robust, customizable solutions for large organizations with 500+ employees.",
    challenges: [
      "Managing global operations",
      "Ensuring data consistency",
      "Maintaining security and compliance",
      "Integrating with legacy systems"
    ],
    benefits: [
      "Standardize operations across regions",
      "Maintain a single source of truth",
      "Meet rigorous security and compliance requirements",
      "Integrate with your existing technology stack"
    ],
    features: [
      "Global deployment capabilities",
      "Advanced security controls",
      "Enterprise API access",
      "Custom development options"
    ]
  },
  
  // By Role
  "sales-teams": {
    title: "Sales Teams",
    category: "role",
    description: "Tools to help sales teams close more deals and manage relationships.",
    challenges: [
      "Managing sales pipelines efficiently",
      "Tracking customer interactions",
      "Forecasting sales accurately",
      "Collaborating across teams"
    ],
    benefits: [
      "Visualize and optimize your sales pipeline",
      "Maintain a complete history of customer interactions",
      "Create accurate sales forecasts",
      "Collaborate seamlessly with marketing and support"
    ],
    features: [
      "CRM with sales automation",
      "Email integration",
      "Sales analytics",
      "Mobile access"
    ]
  },
  "marketing-teams": {
    title: "Marketing Teams",
    category: "role",
    description: "Solutions for creating campaigns, analyzing results, and growing your audience.",
    challenges: [
      "Creating consistent campaigns",
      "Measuring marketing ROI",
      "Managing multiple channels",
      "Generating qualified leads"
    ],
    benefits: [
      "Create cohesive campaigns across channels",
      "Measure the impact of your marketing efforts",
      "Manage all channels from one platform",
      "Generate and nurture high-quality leads"
    ],
    features: [
      "Campaign management",
      "Marketing analytics",
      "Social media integration",
      "Lead generation and scoring"
    ]
  },
  "it-departments": {
    title: "IT Departments",
    category: "role",
    description: "Tools for IT professionals to manage infrastructure, support, and security.",
    challenges: [
      "Ensuring system security",
      "Managing user access",
      "Providing technical support",
      "Maintaining system performance"
    ],
    benefits: [
      "Enhance security across your organization",
      "Simplify user management and access control",
      "Streamline support operations",
      "Optimize system performance"
    ],
    features: [
      "Security management",
      "User administration",
      "Help desk automation",
      "Performance monitoring"
    ]
  },
  "hr-people-ops": {
    title: "HR & People Ops",
    category: "role",
    description: "Solutions for recruiting, onboarding, and managing employee experience.",
    challenges: [
      "Attracting top talent",
      "Streamlining onboarding",
      "Managing employee performance",
      "Maintaining compliance"
    ],
    benefits: [
      "Improve your recruitment process",
      "Create a smooth onboarding experience",
      "Effectively manage employee performance",
      "Stay compliant with employment regulations"
    ],
    features: [
      "Applicant tracking",
      "Onboarding automation",
      "Performance management",
      "Compliance tracking"
    ]
  }
};

// Solution type for TypeScript
type SolutionKey = keyof typeof solutionsData;

const SolutionPage = () => {
  const [match, params] = useRoute("/solutions/:solutionId");
  const [, setLocation] = useLocation();
  
  // Extract the solution ID from the URL
  const solutionId = params?.solutionId as SolutionKey;
  
  // Get the solution data
  const solution = solutionsData[solutionId];
  
  // Redirect to 404 if solution doesn't exist
  useEffect(() => {
    if (!match || !solution) {
      setLocation("/not-found");
    }
  }, [match, solution, setLocation]);
  
  // Return nothing while redirecting
  if (!solution) {
    return null;
  }

  // Determine category text for display
  let categoryText = "";
  switch (solution.category) {
    case "industry":
      categoryText = "Industry";
      break;
    case "size":
      categoryText = "Business Size";
      break;
    case "role":
      categoryText = "Role";
      break;
    default:
      categoryText = "";
  }

  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-primary-700 text-white py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <p className="text-primary-200 font-medium mb-2">Solutions by {categoryText}</p>
              <h1 className="text-4xl font-bold mb-4">{solution.title}</h1>
              <p className="text-xl mb-8 text-primary-100">{solution.description}</p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button variant="secondary" size="lg" asChild>
                  <Link href="/register">Start Free Trial</Link>
                </Button>
                <Button variant="outline" size="lg" className="bg-transparent border border-white text-white hover:bg-white/10" asChild>
                  <Link href="/demo">Watch Demo</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
        
        {/* Challenges Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Key Challenges</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Common challenges faced by {solution.title}.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {solution.challenges.map((challenge, index) => (
                <div 
                  key={index}
                  className="bg-white rounded-lg shadow-md p-6 border border-gray-100"
                >
                  <h3 className="text-xl font-semibold mb-2">{challenge}</h3>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        {/* Benefits Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">How BizSuite Helps</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Our solutions address your specific needs.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {solution.benefits.map((benefit, index) => (
                <div 
                  key={index}
                  className="bg-white rounded-lg shadow-md p-6 border border-gray-100"
                >
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mr-4">
                      <div className="h-8 w-8 bg-primary-100 text-primary rounded-full flex items-center justify-center">
                        <Check className="h-4 w-4" />
                      </div>
                    </div>
                    <div>
                      <p className="text-lg">{benefit}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        {/* Features Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Key Features</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Specialized features for {solution.title}.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {solution.features.map((feature, index) => (
                <div 
                  key={index}
                  className="bg-white rounded-lg shadow-md p-6 border border-gray-100 text-center"
                >
                  <h3 className="text-lg font-semibold mb-2">{feature}</h3>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-16 bg-primary-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to get started?</h2>
            <p className="text-xl text-primary-100 max-w-3xl mx-auto mb-8">
              Join thousands of {solution.title} using BizSuite to transform their operations.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button variant="secondary" size="lg" asChild>
                <Link href="/register">Start Free Trial</Link>
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="bg-transparent border border-white text-white hover:bg-white/10"
                asChild
              >
                <Link href="/contact">Talk to Sales</Link>
              </Button>
            </div>
            <p className="mt-4 text-sm text-primary-200">No credit card required. 14-day free trial.</p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default SolutionPage;