import { useState } from "react";
import { Link } from "wouter";
import { Search, Phone, Mail, MessageSquare, FileText, HelpCircle, ChevronRight } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

// FAQ data
const faqData = [
  {
    question: "How do I reset my password?",
    answer: "To reset your password, click on the 'Forgot password?' link on the sign-in page. You will receive an email with instructions to create a new password."
  },
  {
    question: "Can I change my subscription plan?",
    answer: "Yes, you can upgrade or downgrade your subscription plan at any time from your account settings. Changes to your subscription will be effective immediately, with prorated billing adjustments."
  },
  {
    question: "How do I add team members to my account?",
    answer: "To add team members, go to your account settings, select 'Team Management', and click 'Add Member'. Enter their email address and assign appropriate permissions. They will receive an invitation to join your account."
  },
  {
    question: "Is there a limit to how many users I can add?",
    answer: "The number of users you can add depends on your subscription plan. Basic plans typically allow up to 5 users, while Professional and Enterprise plans offer more flexible user limits. Check your plan details for specific information."
  },
  {
    question: "Do you offer custom integrations?",
    answer: "Yes, we offer custom integrations for our Professional and Enterprise plans. Please contact our sales team to discuss your specific integration needs and get a personalized quote."
  },
  {
    question: "What payment methods do you accept?",
    answer: "We accept major credit cards (Visa, MasterCard, American Express), PayPal, and bank transfers for annual subscriptions. For Enterprise plans, we also offer invoicing options."
  },
  {
    question: "Can I export my data if I decide to cancel?",
    answer: "Yes, you can export all your data in standard formats (CSV, JSON, etc.) at any time, including when you cancel your subscription. We retain your data for 30 days after cancellation, after which it is permanently deleted."
  },
  {
    question: "Do you offer discounts for nonprofits or educational institutions?",
    answer: "Yes, we offer special pricing for qualified nonprofit organizations, educational institutions, and startups. Please contact our sales team with appropriate documentation to apply for these discounts."
  }
];

const SupportPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [contactName, setContactName] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [contactSubject, setContactSubject] = useState("");
  const [contactMessage, setContactMessage] = useState("");
  const { toast } = useToast();
  
  // Filter FAQs based on search query
  const filteredFaqs = faqData.filter(faq => 
    faq.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
    faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real application, this would submit to a support ticket system
    // For now, we'll just show a toast message
    if (contactName && contactEmail && contactSubject && contactMessage) {
      toast({
        title: "Support request sent",
        description: "We've received your message and will respond shortly.",
      });
      
      // Reset form
      setContactName("");
      setContactEmail("");
      setContactSubject("");
      setContactMessage("");
    } else {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
    }
  };

  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-primary-700 text-white py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl font-bold mb-4">How Can We Help You?</h1>
              <p className="text-xl mb-8 text-primary-100">
                Find answers, get support, or contact our team.
              </p>
              <div className="relative max-w-2xl mx-auto">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <Input 
                  type="text"
                  placeholder="Search for answers..."
                  className="pl-10 bg-white text-gray-900 placeholder-gray-500"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
          </div>
        </section>
        
        {/* Support Options Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Support Options</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Choose the support option that works best for you.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <Card>
                <CardHeader>
                  <div className="h-12 w-12 rounded-full bg-primary-100 text-primary flex items-center justify-center mb-4">
                    <Phone className="h-6 w-6" />
                  </div>
                  <CardTitle>Phone Support</CardTitle>
                  <CardDescription>
                    Speak directly with our support team.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="mb-4 text-gray-600">
                    Available Monday-Friday, 9am-6pm EST.
                  </p>
                  <p className="font-medium text-primary">+1 (800) 123-4567</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <div className="h-12 w-12 rounded-full bg-primary-100 text-primary flex items-center justify-center mb-4">
                    <Mail className="h-6 w-6" />
                  </div>
                  <CardTitle>Email Support</CardTitle>
                  <CardDescription>
                    Send us an email and we'll respond within 24 hours.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="mb-4 text-gray-600">
                    Our team is available 24/7 for email support.
                  </p>
                  <p className="font-medium text-primary">support@example.com</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <div className="h-12 w-12 rounded-full bg-primary-100 text-primary flex items-center justify-center mb-4">
                    <MessageSquare className="h-6 w-6" />
                  </div>
                  <CardTitle>Live Chat</CardTitle>
                  <CardDescription>
                    Chat with our support team in real-time.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="mb-4 text-gray-600">
                    Available Monday-Friday, 9am-9pm EST.
                  </p>
                  <Button>Start Chat</Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
        
        {/* FAQs Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Find quick answers to common questions.
              </p>
            </div>
            
            <div className="max-w-3xl mx-auto">
              {searchQuery && filteredFaqs.length === 0 ? (
                <div className="text-center py-8">
                  <HelpCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No results found</h3>
                  <p className="text-gray-600 mb-4">
                    We couldn't find any answers matching "{searchQuery}"
                  </p>
                  <Button onClick={() => setSearchQuery("")}>Clear Search</Button>
                </div>
              ) : (
                <Accordion type="single" collapsible className="bg-white rounded-lg shadow-md border border-gray-200">
                  {filteredFaqs.map((faq, index) => (
                    <AccordionItem key={index} value={`item-${index}`}>
                      <AccordionTrigger className="px-6 py-4 hover:no-underline">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="px-6 pb-4">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )}
              
              <div className="text-center mt-8">
                <Link href="/knowledgebase" className="text-primary hover:text-primary-700 font-medium flex items-center gap-1 justify-center">
                  Browse all articles in the knowledge base
                  <ChevronRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        </section>
        
        {/* Contact Form Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold mb-4">Contact Us</h2>
                <p className="text-xl text-gray-600">
                  Can't find what you're looking for? Send us a message.
                </p>
              </div>
              
              <form onSubmit={handleContactSubmit} className="bg-white rounded-lg shadow-md border border-gray-200 p-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                      Name
                    </label>
                    <Input
                      id="name"
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <Input
                      id="email"
                      type="email"
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>
                
                <div className="mb-6">
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                    Subject
                  </label>
                  <Input
                    id="subject"
                    value={contactSubject}
                    onChange={(e) => setContactSubject(e.target.value)}
                    required
                  />
                </div>
                
                <div className="mb-6">
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                    Message
                  </label>
                  <Textarea
                    id="message"
                    rows={6}
                    value={contactMessage}
                    onChange={(e) => setContactMessage(e.target.value)}
                    required
                  />
                </div>
                
                <Button type="submit" className="w-full">Send Message</Button>
              </form>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default SupportPage;