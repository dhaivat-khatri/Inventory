export interface NavItem {
  label: string;
  href?: string;
  dropdown: boolean;
  children?: {
    label: string;
    href: string;
  }[];
}

export const navItems: NavItem[] = [
  {
    label: "Products",
    dropdown: true,
    children: [
      { label: "CRM", href: "/products/crm" },
      { label: "Email Marketing", href: "/products/email-marketing" },
      { label: "Finance", href: "/products/finance" },
      { label: "HR Management", href: "/products/hr" },
      { label: "Project Management", href: "/products/project-management" },
      { label: "Customer Support", href: "/products/customer-support" },
      { label: "Inventory", href: "/inventory" }
    ]
  },
  {
    label: "Solutions",
    dropdown: true,
    children: [
      // By Industry
      { label: "Financial Services", href: "/solutions/financial-services" },
      { label: "Healthcare", href: "/solutions/healthcare" },
      { label: "Manufacturing", href: "/solutions/manufacturing" },
      { label: "Retail", href: "/solutions/retail" },
      
      // By Business Size
      { label: "Small Business", href: "/solutions/small-business" },
      { label: "Mid-Market", href: "/solutions/mid-market" },
      { label: "Enterprise", href: "/solutions/enterprise" },
      
      // By Role
      { label: "Sales Teams", href: "/solutions/sales-teams" },
      { label: "Marketing Teams", href: "/solutions/marketing-teams" },
      { label: "IT Departments", href: "/solutions/it-departments" },
      { label: "HR & People Ops", href: "/solutions/hr-people-ops" }
    ]
  },
  {
    label: "Pricing",
    href: "/pricing",
    dropdown: false
  },
  {
    label: "Resources",
    href: "/resources",
    dropdown: false
  },
  {
    label: "Support",
    href: "/support",
    dropdown: false
  }
];
