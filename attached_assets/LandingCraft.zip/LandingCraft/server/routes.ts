import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertIntegrationConnectionSchema, 
  insertProductSchema,
  insertUserAchievementSchema
} from "@shared/schema";

// Middleware to check if user is authenticated
const authenticateUser = async (req: Request, res: Response, next: Function) => {
  const userId = req.session.userId;
  
  if (!userId) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  
  const user = await storage.getUser(userId);
  if (!user) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  
  req.user = user;
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  /*** Authentication Routes ***/
  
  // Register
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ error: "Username already exists" });
      }
      
      const existingEmail = await storage.getUserByEmail(validatedData.email);
      if (existingEmail) {
        return res.status(400).json({ error: "Email already exists" });
      }
      
      // Create user
      const newUser = await storage.createUser(validatedData);
      
      // Create the first achievement for signing up
      await storage.createUserAchievement({
        userId: newUser.id,
        achievementType: "onboarding",
        achievementName: "Signed Up",
        pointsAwarded: 10
      });
      
      // Update user points
      await storage.updateUser(newUser.id, { engagementPoints: 10 });
      
      // Clean the response (remove password)
      const { password, ...userWithoutPassword } = newUser;
      
      // Set session
      req.session.userId = newUser.id;
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Registration failed" });
    }
  });
  
  // Login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ error: "Username and password required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      // Set session
      req.session.userId = user.id;
      
      // Clean the response (remove password)
      const { password: _, ...userWithoutPassword } = user;
      
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ error: "Login failed" });
    }
  });
  
  // Get current user
  app.get("/api/auth/me", authenticateUser, (req, res) => {
    // Clean the response (remove password)
    const { password, ...userWithoutPassword } = req.user;
    res.json(userWithoutPassword);
  });
  
  // Logout
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Logout failed" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });
  
  // Update onboarding status
  app.put("/api/auth/onboarding", authenticateUser, async (req, res) => {
    try {
      const { onboardingCompleted } = req.body;
      
      if (onboardingCompleted === true && !req.user.onboardingCompleted) {
        // First time completing onboarding - award points
        await storage.createUserAchievement({
          userId: req.user.id,
          achievementType: "onboarding",
          achievementName: "Completed Onboarding",
          pointsAwarded: 20
        });
        
        // Update user points
        const updatedPoints = req.user.engagementPoints + 20;
        await storage.updateUser(req.user.id, { 
          onboardingCompleted: true,
          engagementPoints: updatedPoints 
        });
        
        const updatedUser = await storage.getUser(req.user.id);
        if (!updatedUser) {
          return res.status(500).json({ error: "Failed to update user" });
        }
        
        // Clean the response (remove password)
        const { password, ...userWithoutPassword } = updatedUser;
        
        return res.json(userWithoutPassword);
      }
      
      // Just update onboarding status without points
      await storage.updateUser(req.user.id, { 
        onboardingCompleted: !!onboardingCompleted
      });
      
      const updatedUser = await storage.getUser(req.user.id);
      if (!updatedUser) {
        return res.status(500).json({ error: "Failed to update user" });
      }
      
      // Clean the response (remove password)
      const { password, ...userWithoutPassword } = updatedUser;
      
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ error: "Failed to update onboarding status" });
    }
  });
  
  /*** Integration Routes ***/
  
  // Get all integrations for current user
  app.get("/api/integrations", authenticateUser, async (req, res) => {
    try {
      const integrations = await storage.getIntegrationConnections(req.user.id);
      res.json(integrations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch integrations" });
    }
  });
  
  // Get a specific integration
  app.get("/api/integrations/:id", authenticateUser, async (req, res) => {
    try {
      const integration = await storage.getIntegrationConnection(parseInt(req.params.id));
      
      if (!integration) {
        return res.status(404).json({ error: "Integration not found" });
      }
      
      if (integration.userId !== req.user.id) {
        return res.status(403).json({ error: "Forbidden" });
      }
      
      res.json(integration);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch integration" });
    }
  });
  
  // Create a new integration connection
  app.post("/api/integrations", authenticateUser, async (req, res) => {
    try {
      // Validate with the schema but add userId
      const validatedData = { 
        ...insertIntegrationConnectionSchema.parse(req.body),
        userId: req.user.id
      };
      
      // Check if already connected
      const existingIntegration = await storage.getIntegrationConnectionByProvider(
        req.user.id, 
        validatedData.provider
      );
      
      if (existingIntegration) {
        return res.status(400).json({ error: "Integration already connected" });
      }
      
      const newIntegration = await storage.createIntegrationConnection(validatedData);
      res.status(201).json(newIntegration);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create integration" });
    }
  });
  
  // Update integration connection
  app.put("/api/integrations/:id", authenticateUser, async (req, res) => {
    try {
      const integrationId = parseInt(req.params.id);
      const integration = await storage.getIntegrationConnection(integrationId);
      
      if (!integration) {
        return res.status(404).json({ error: "Integration not found" });
      }
      
      if (integration.userId !== req.user.id) {
        return res.status(403).json({ error: "Forbidden" });
      }
      
      const updatedIntegration = await storage.updateIntegrationConnection(
        integrationId, 
        req.body
      );
      
      res.json(updatedIntegration);
    } catch (error) {
      res.status(500).json({ error: "Failed to update integration" });
    }
  });
  
  // Delete integration connection
  app.delete("/api/integrations/:id", authenticateUser, async (req, res) => {
    try {
      const integrationId = parseInt(req.params.id);
      const integration = await storage.getIntegrationConnection(integrationId);
      
      if (!integration) {
        return res.status(404).json({ error: "Integration not found" });
      }
      
      if (integration.userId !== req.user.id) {
        return res.status(403).json({ error: "Forbidden" });
      }
      
      await storage.deleteIntegrationConnection(integrationId);
      res.json({ message: "Integration deleted successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete integration" });
    }
  });
  
  /*** Product Routes ***/
  
  // Get all products for current user
  app.get("/api/products", authenticateUser, async (req, res) => {
    try {
      const products = await storage.getProducts(req.user.id);
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });
  
  // Get a specific product
  app.get("/api/products/:id", authenticateUser, async (req, res) => {
    try {
      const product = await storage.getProduct(parseInt(req.params.id));
      
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      
      if (product.userId !== req.user.id) {
        return res.status(403).json({ error: "Forbidden" });
      }
      
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });
  
  // Create a new product
  app.post("/api/products", authenticateUser, async (req, res) => {
    try {
      // Validate with the schema but add userId
      const validatedData = { 
        ...insertProductSchema.parse(req.body),
        userId: req.user.id
      };
      
      const newProduct = await storage.createProduct(validatedData);
      res.status(201).json(newProduct);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create product" });
    }
  });
  
  // Update product
  app.put("/api/products/:id", authenticateUser, async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const product = await storage.getProduct(productId);
      
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      
      if (product.userId !== req.user.id) {
        return res.status(403).json({ error: "Forbidden" });
      }
      
      const updatedProduct = await storage.updateProduct(
        productId, 
        req.body
      );
      
      res.json(updatedProduct);
    } catch (error) {
      res.status(500).json({ error: "Failed to update product" });
    }
  });
  
  // Delete product
  app.delete("/api/products/:id", authenticateUser, async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const product = await storage.getProduct(productId);
      
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      
      if (product.userId !== req.user.id) {
        return res.status(403).json({ error: "Forbidden" });
      }
      
      await storage.deleteProduct(productId);
      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete product" });
    }
  });
  
  /*** User Achievement & Gamification Routes ***/
  
  // Get all achievements for current user
  app.get("/api/achievements", authenticateUser, async (req, res) => {
    try {
      const achievements = await storage.getUserAchievements(req.user.id);
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch achievements" });
    }
  });
  
  // Get engagement points for current user
  app.get("/api/engagement-points", authenticateUser, async (req, res) => {
    try {
      const points = await storage.getUserEngagementPoints(req.user.id);
      res.json({ points });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch engagement points" });
    }
  });
  
  // Update dashboard preferences
  app.put("/api/dashboard-preferences", authenticateUser, async (req, res) => {
    try {
      const { dashboardPreferences } = req.body;
      
      await storage.updateUser(req.user.id, { dashboardPreferences });
      
      const updatedUser = await storage.getUser(req.user.id);
      if (!updatedUser) {
        return res.status(500).json({ error: "Failed to update user" });
      }
      
      res.json({ dashboardPreferences: updatedUser.dashboardPreferences });
    } catch (error) {
      res.status(500).json({ error: "Failed to update dashboard preferences" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
