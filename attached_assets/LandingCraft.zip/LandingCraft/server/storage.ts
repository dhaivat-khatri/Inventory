import { 
  users, type User, type InsertUser,
  integrationConnections, type IntegrationConnection, type InsertIntegrationConnection,
  products, type Product, type InsertProduct,
  userAchievements, type UserAchievement, type InsertUserAchievement
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  // Integration connection methods
  getIntegrationConnections(userId: number): Promise<IntegrationConnection[]>;
  getIntegrationConnection(id: number): Promise<IntegrationConnection | undefined>;
  getIntegrationConnectionByProvider(userId: number, provider: string): Promise<IntegrationConnection | undefined>;
  createIntegrationConnection(connection: InsertIntegrationConnection): Promise<IntegrationConnection>;
  updateIntegrationConnection(id: number, updates: Partial<IntegrationConnection>): Promise<IntegrationConnection | undefined>;
  deleteIntegrationConnection(id: number): Promise<boolean>;
  
  // Product methods
  getProducts(userId: number): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, updates: Partial<Product>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  
  // Achievement methods
  getUserAchievements(userId: number): Promise<UserAchievement[]>;
  createUserAchievement(achievement: InsertUserAchievement): Promise<UserAchievement>;
  getUserEngagementPoints(userId: number): Promise<number>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private integrationConnections: Map<number, IntegrationConnection>;
  private products: Map<number, Product>;
  private userAchievements: Map<number, UserAchievement>;
  
  private userId: number;
  private integrationId: number;
  private productId: number;
  private achievementId: number;

  constructor() {
    this.users = new Map();
    this.integrationConnections = new Map();
    this.products = new Map();
    this.userAchievements = new Map();
    
    this.userId = 1;
    this.integrationId = 1;
    this.productId = 1;
    this.achievementId = 1;
    
    // Create a demo user
    const demoUser: User = {
      id: this.userId++,
      username: "demo",
      password: "password", // In a real app, this would be hashed
      email: "demo@example.com",
      fullName: "Demo User",
      role: "user",
      company: "Demo Company",
      onboardingCompleted: true,
      engagementPoints: 150,
      dashboardPreferences: {},
      createdAt: new Date()
    };
    this.users.set(demoUser.id, demoUser);
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    
    const user: User = { 
      ...insertUser, 
      id, 
      role: "user",
      onboardingCompleted: false,
      engagementPoints: 0,
      dashboardPreferences: {},
      createdAt: now
    };
    
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Integration connection methods
  async getIntegrationConnections(userId: number): Promise<IntegrationConnection[]> {
    return Array.from(this.integrationConnections.values())
      .filter(conn => conn.userId === userId);
  }
  
  async getIntegrationConnection(id: number): Promise<IntegrationConnection | undefined> {
    return this.integrationConnections.get(id);
  }
  
  async getIntegrationConnectionByProvider(userId: number, provider: string): Promise<IntegrationConnection | undefined> {
    return Array.from(this.integrationConnections.values())
      .find(conn => conn.userId === userId && conn.provider === provider);
  }
  
  async createIntegrationConnection(connection: InsertIntegrationConnection): Promise<IntegrationConnection> {
    const id = this.integrationId++;
    const now = new Date();
    
    const newConnection: IntegrationConnection = {
      ...connection,
      id,
      status: "active",
      metadata: connection.metadata || {},
      createdAt: now,
      updatedAt: now
    };
    
    this.integrationConnections.set(id, newConnection);
    
    // Add engagement points for connecting a new integration
    const user = await this.getUser(connection.userId);
    if (user) {
      const updatedPoints = user.engagementPoints + 50;
      await this.updateUser(user.id, { engagementPoints: updatedPoints });
      
      // Create achievement for connecting integration
      await this.createUserAchievement({
        userId: user.id,
        achievementType: "integration",
        achievementName: `Connected ${connection.provider}`,
        pointsAwarded: 50
      });
    }
    
    return newConnection;
  }
  
  async updateIntegrationConnection(id: number, updates: Partial<IntegrationConnection>): Promise<IntegrationConnection | undefined> {
    const connection = this.integrationConnections.get(id);
    if (!connection) return undefined;
    
    const updatedConnection = { 
      ...connection, 
      ...updates, 
      updatedAt: new Date() 
    };
    
    this.integrationConnections.set(id, updatedConnection);
    return updatedConnection;
  }
  
  async deleteIntegrationConnection(id: number): Promise<boolean> {
    return this.integrationConnections.delete(id);
  }
  
  // Product methods
  async getProducts(userId: number): Promise<Product[]> {
    return Array.from(this.products.values())
      .filter(product => product.userId === userId);
  }
  
  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }
  
  async createProduct(product: InsertProduct): Promise<Product> {
    const id = this.productId++;
    const now = new Date();
    
    const newProduct: Product = {
      ...product,
      id,
      metadata: product.metadata || {},
      createdAt: now,
      updatedAt: now
    };
    
    this.products.set(id, newProduct);
    
    // Add points for adding a new product (first 10 products)
    const userProducts = await this.getProducts(product.userId);
    if (userProducts.length <= 10) {
      const user = await this.getUser(product.userId);
      if (user) {
        const updatedPoints = user.engagementPoints + 5;
        await this.updateUser(user.id, { engagementPoints: updatedPoints });
        
        if (userProducts.length === 10) {
          // Achievement for adding 10 products
          await this.createUserAchievement({
            userId: user.id,
            achievementType: "inventory",
            achievementName: "Added 10 products",
            pointsAwarded: 50
          });
        }
      }
    }
    
    return newProduct;
  }
  
  async updateProduct(id: number, updates: Partial<Product>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    
    const updatedProduct = { 
      ...product, 
      ...updates, 
      updatedAt: new Date() 
    };
    
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }
  
  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }
  
  // Achievement methods
  async getUserAchievements(userId: number): Promise<UserAchievement[]> {
    return Array.from(this.userAchievements.values())
      .filter(achievement => achievement.userId === userId);
  }
  
  async createUserAchievement(achievement: InsertUserAchievement): Promise<UserAchievement> {
    const id = this.achievementId++;
    
    const newAchievement: UserAchievement = {
      ...achievement,
      id,
      achievedAt: new Date()
    };
    
    this.userAchievements.set(id, newAchievement);
    return newAchievement;
  }
  
  async getUserEngagementPoints(userId: number): Promise<number> {
    const user = await this.getUser(userId);
    return user?.engagementPoints || 0;
  }
}

export const storage = new MemStorage();
