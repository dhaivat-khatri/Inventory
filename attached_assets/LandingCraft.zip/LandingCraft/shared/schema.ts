import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  role: text("role").default("user"),
  company: text("company"),
  onboardingCompleted: boolean("onboarding_completed").default(false),
  engagementPoints: integer("engagement_points").default(0),
  dashboardPreferences: jsonb("dashboard_preferences").default({}),
  createdAt: timestamp("created_at").defaultNow()
});

export const integrationConnections = pgTable("integration_connections", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  provider: text("provider").notNull(), // e.g., "shopify", "amazon", "quickbooks"
  providerAccountId: text("provider_account_id").notNull(),
  accessToken: text("access_token").notNull(),
  refreshToken: text("refresh_token"),
  expiresAt: timestamp("expires_at"),
  status: text("status").default("active"),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  sku: text("sku").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  price: integer("price").notNull(), // stored in cents
  quantity: integer("quantity").default(0),
  category: text("category"),
  imageUrl: text("image_url"),
  source: text("source"), // which integration this came from
  sourceId: text("source_id"), // ID in original system
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  achievementType: text("achievement_type").notNull(), // e.g., "onboarding", "integration", "inventory"
  achievementName: text("achievement_name").notNull(),
  pointsAwarded: integer("points_awarded").notNull(),
  achievedAt: timestamp("achieved_at").defaultNow()
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  fullName: true,
  company: true,
});

export const insertIntegrationConnectionSchema = createInsertSchema(integrationConnections).pick({
  userId: true,
  provider: true,
  providerAccountId: true,
  accessToken: true,
  refreshToken: true,
  expiresAt: true,
  metadata: true,
});

export const insertProductSchema = createInsertSchema(products).pick({
  userId: true,
  sku: true,
  name: true,
  description: true,
  price: true,
  quantity: true,
  category: true,
  imageUrl: true,
  source: true,
  sourceId: true,
  metadata: true,
});

export const insertUserAchievementSchema = createInsertSchema(userAchievements).pick({
  userId: true,
  achievementType: true,
  achievementName: true,
  pointsAwarded: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertIntegrationConnection = z.infer<typeof insertIntegrationConnectionSchema>;
export type IntegrationConnection = typeof integrationConnections.$inferSelect;

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;
export type UserAchievement = typeof userAchievements.$inferSelect;
